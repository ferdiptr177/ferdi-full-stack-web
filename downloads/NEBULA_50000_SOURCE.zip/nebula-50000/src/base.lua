-- NEBULA ULTRA | Client panel, no remote downloads.
-- Local changes can be rejected by the server. No server god mode.

local Players = game:GetService("Players")
local Run = game:GetService("RunService")
local Input = game:GetService("UserInputService")
local Lighting = game:GetService("Lighting")
local Http = game:GetService("HttpService")
local Stats = game:GetService("Stats")
local player = Players.LocalPlayer
assert(player, "Run NEBULA ULTRA on the Roblox client")

local env = type(getgenv) == "function" and getgenv() or _G
local previous = env.__NEBULA_PANEL
if type(previous) == "table" and type(previous.Destroy) == "function" then
    previous.Destroy()
end

local alive, generation = true, 0
local connections, widgets, features, rows, tabs = {}, {}, {}, {}, {}
local character, humanoid, root, selectedPlayer
local savedPlaces, lastPosition, sessionProfile = {}, nil, nil
local activeFlight, nightEffect
local upHeld, downHeld, focused = false, false, true
local pointerHolds = {}
local currentTab, query = "Move", ""
local footer, toast, panel, gui, launcher, scaleObject
local notification, notificationUntil = "NEBULA ULTRA siap", 0

local defaults = {
    speed = false, walkSpeed = 32, jump = false, jumpPower = 85,
    fly = false, flySpeed = 50, noclip = false, airJump = false,
    fullbright = false, clearFog = false, nightVision = false,
    noBlur = false, customTime = false, clockTime = 14,
    fov = false, fieldOfView = 85, zoom = false, zoomDistance = 128,
    invisibleSelf = false, highlights = false, nameplates = false,
    spectate = false, uiScale = 1, stats = true, theme = "Purple",
}
local bounds = {
    walkSpeed = { 8, 120, 2 }, jumpPower = { 30, 160, 5 },
    flySpeed = { 10, 160, 5 }, clockTime = { 0, 24, 0.5 },
    fieldOfView = { 40, 110, 1 }, zoomDistance = { 16, 512, 8 },
    uiScale = { 0.7, 1.3, 0.05 },
}
local values = table.clone(defaults)
local themes = {
    Purple = Color3.fromRGB(163, 116, 255),
    Cyan = Color3.fromRGB(63, 208, 231),
    Emerald = Color3.fromRGB(70, 214, 153),
    Rose = Color3.fromRGB(245, 115, 160),
}
local accent = themes.Purple
local textColor = Color3.fromRGB(239, 237, 247)
local muted = Color3.fromRGB(169, 163, 188)
local surface = Color3.fromRGB(35, 32, 49)
local accentBindings = {}

local function connect(signal, callback)
    local connection = signal:Connect(callback)
    table.insert(connections, connection)
    return connection
end

local function new(class, properties, parent)
    local object = Instance.new(class)
    for key, value in pairs(properties or {}) do object[key] = value end
    object.Parent = parent
    return object
end

local function round(object, radius)
    new("UICorner", { CornerRadius = UDim.new(0, radius or 10) }, object)
end

local function colored(object, property)
    object[property] = accent
    table.insert(accentBindings, { object, property })
    return object
end

local function notify(message)
    notification = tostring(message)
    notificationUntil = os.clock() + 5
    if footer then footer.Text = notification end
    if toast then toast.Text = notification; toast.Visible = true end
end

local function guarded(callback)
    return function(...)
        if not alive then return end
        local ok, err = pcall(callback, ...)
        if not ok then notify("Error: " .. tostring(err):sub(1, 160)) end
    end
end

local function sync(key)
    for _, update in ipairs(widgets[key] or {}) do update() end
end

local function watch(key, update)
    widgets[key] = widgets[key] or {}
    table.insert(widgets[key], update)
    update()
end

-- Layered overrides keep overlapping features independent.
local properties = setmetatable({}, { __mode = "k" })
local function applyProperty(object, property, cell)
    local chosen, priority = cell.base, -math.huge
    for _, layer in pairs(cell.layers) do
        if layer.priority > priority then
            chosen, priority = layer.value, layer.priority
        end
    end
    if object[property] ~= chosen then object[property] = chosen end
end

local function put(owner, object, property, value, priority)
    if not object then return end
    local list = properties[object]
    if not list then list = {}; properties[object] = list end
    local cell = list[property]
    if not cell then
        cell = { base = object[property], layers = {} }
        list[property] = cell
    end
    cell.layers[owner] = { value = value, priority = priority or 10 }
    applyProperty(object, property, cell)
end

local function release(owner)
    for object, list in pairs(properties) do
        for property, cell in pairs(list) do
            if cell.layers[owner] then
                cell.layers[owner] = nil
                pcall(applyProperty, object, property, cell)
                if next(cell.layers) == nil then list[property] = nil end
            end
        end
        if next(list) == nil then properties[object] = nil end
    end
end

local function restoreAll()
    for object, list in pairs(properties) do
        for property, cell in pairs(list) do
            pcall(function() object[property] = cell.base end)
        end
    end
    table.clear(properties)
end

local function define(key, enable, disable)
    features[key] = { enable = enable, disable = disable }
end

local function setFeature(key, enabled)
    local feature = features[key]
    if not feature then return end
    if values[key] == enabled then sync(key); return end
    values[key] = enabled
    local ok, err = pcall(function()
        if enabled then
            feature.enable()
        else
            if feature.disable then feature.disable() end
            release(key)
        end
    end)
    if not ok then
        values[key] = false
        if feature.disable then pcall(feature.disable) end
        release(key)
        notify(key .. ": " .. tostring(err):sub(1, 130))
    end
    sync(key)
end

local function refreshFeature(key)
    if values[key] and features[key] then features[key].enable() end
end

local function liveRoot()
    return root and root.Parent and humanoid and humanoid.Health > 0
end

local function applySpeed()
    if humanoid then put("speed", humanoid, "WalkSpeed", values.walkSpeed) end
end

local function applyJump()
    if not humanoid then return end
    put("jump", humanoid, "JumpPower", values.jumpPower)
    put("jump", humanoid, "JumpHeight", values.jumpPower ^ 2 / (2 * math.max(workspace.Gravity, 1)))
end

local function stopFlight()
    upHeld, downHeld = false, false
    table.clear(pointerHolds)
    if not activeFlight then release("fly"); return end
    local old = activeFlight
    activeFlight = nil
    old.velocity:Destroy()
    old.orientation:Destroy()
    old.attachment:Destroy()
    release("fly")
    if old.root.Parent then
        old.root.AssemblyLinearVelocity = Vector3.zero
        old.root.AssemblyAngularVelocity = Vector3.zero
    end
    if old.humanoid.Parent and old.humanoid.Health > 0 and not old.humanoid.PlatformStand then
        old.humanoid:ChangeState(Enum.HumanoidStateType.GettingUp)
    end
end

local flightPad
local function startFlight()
    if activeFlight or not liveRoot() then return end
    assert(not humanoid.Sit, "Keluar dari kursi/kendaraan terlebih dahulu")
    local attachment = new("Attachment", { Name = "NebulaFlight" }, root)
    local velocity = new("LinearVelocity", {
        Attachment0 = attachment, RelativeTo = Enum.ActuatorRelativeTo.World,
        MaxForce = math.huge, VectorVelocity = Vector3.zero,
    }, root)
    local orientation = new("AlignOrientation", {
        Attachment0 = attachment, Mode = Enum.OrientationAlignmentMode.OneAttachment,
        MaxTorque = math.huge, Responsiveness = 18, CFrame = root.CFrame.Rotation,
    }, root)
    activeFlight = {
        attachment = attachment, velocity = velocity, orientation = orientation,
        humanoid = humanoid, root = root,
    }
    put("fly", humanoid, "AutoRotate", false)
    put("fly", humanoid, "PlatformStand", true)
end

define("speed", applySpeed)
define("jump", applyJump)
define("fly", function()
    startFlight()
    if flightPad then flightPad.Visible = true end
end, function()
    stopFlight()
    if flightPad then flightPad.Visible = false end
end)
define("noclip", function() end)
define("airJump", function() end)

define("fullbright", function()
    put("fullbright", Lighting, "Brightness", 2)
    put("fullbright", Lighting, "ClockTime", 14)
    put("fullbright", Lighting, "GlobalShadows", false)
    put("fullbright", Lighting, "Ambient", Color3.fromRGB(180, 180, 180))
    put("fullbright", Lighting, "OutdoorAmbient", Color3.fromRGB(180, 180, 180))
end)
define("clearFog", function() put("clearFog", Lighting, "FogEnd", 1000000) end)
define("customTime", function() put("customTime", Lighting, "ClockTime", values.clockTime, 20) end)
define("nightVision", function()
    if nightEffect then return end
    nightEffect = new("ColorCorrectionEffect", {
        Name = "NebulaNightVision", Brightness = 0.15,
        Contrast = 0.1, Saturation = -0.25,
        TintColor = Color3.fromRGB(190, 255, 205),
    }, Lighting)
end, function()
    if nightEffect then nightEffect:Destroy(); nightEffect = nil end
end)

local function removeBlur()
    local containers = { Lighting }
    if workspace.CurrentCamera then table.insert(containers, workspace.CurrentCamera) end
    for _, container in ipairs(containers) do
        for _, effect in ipairs(container:GetChildren()) do
            if effect:IsA("BlurEffect") or effect:IsA("DepthOfFieldEffect") then
                put("noBlur", effect, "Enabled", false)
            end
        end
    end
end
define("noBlur", removeBlur)
define("fov", function()
    put("fov", workspace.CurrentCamera, "FieldOfView", values.fieldOfView)
end)
define("zoom", function() put("zoom", player, "CameraMaxZoomDistance", values.zoomDistance) end)

local function hideSelf()
    if not character then return end
    for _, part in ipairs(character:GetDescendants()) do
        if part:IsA("BasePart") then put("invisibleSelf", part, "LocalTransparencyModifier", 1) end
    end
end
define("invisibleSelf", hideSelf)

local effectFolder = new("Folder", { Name = "NebulaUltraLocalEffects" }, workspace)
local playerEffects = {}
local function clearPlayerEffects(kind)
    for other, effects in pairs(playerEffects) do
        if effects[kind] then effects[kind]:Destroy(); effects[kind] = nil end
        if kind == "tag" then effects.caption = nil end
        if not effects.highlight and not effects.tag then playerEffects[other] = nil end
    end
end

local function updatePlayers()
    local present = {}
    for _, other in ipairs(Players:GetPlayers()) do
        if other ~= player then
            present[other] = true
            local model = other.Character
            local target = model and model:FindFirstChild("HumanoidRootPart")
            local head = model and (model:FindFirstChild("Head") or target)
            local effects = playerEffects[other] or {}
            playerEffects[other] = effects
            if effects.model ~= model then
                if effects.highlight then effects.highlight:Destroy() end
                if effects.tag then effects.tag:Destroy() end
                effects.highlight, effects.tag, effects.caption = nil, nil, nil
                effects.model = model
            end
            if effects.tag and effects.tag.Adornee ~= head then
                effects.tag:Destroy()
                effects.tag, effects.caption = nil, nil
            end
            local color = other.Team and other.TeamColor.Color or accent
            if values.highlights and model and not effects.highlight then
                effects.highlight = new("Highlight", {
                    Adornee = model, DepthMode = Enum.HighlightDepthMode.AlwaysOnTop,
                    FillTransparency = 0.8, OutlineTransparency = 0.1,
                }, effectFolder)
            end
            if effects.highlight then
                effects.highlight.FillColor, effects.highlight.OutlineColor = color, color
            end
            if values.nameplates and head and not effects.tag then
                effects.tag = new("BillboardGui", {
                    Adornee = head, AlwaysOnTop = true,
                    Size = UDim2.fromOffset(180, 42), MaxDistance = 1500,
                    StudsOffsetWorldSpace = Vector3.new(0, 3, 0),
                }, effectFolder)
                effects.caption = new("TextLabel", {
                    Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1,
                    Font = Enum.Font.GothamBold, TextSize = 12,
                    TextStrokeTransparency = 0.3, TextColor3 = color,
                }, effects.tag)
            end
            if effects.caption then
                local distance = root and target and math.floor((root.Position - target.Position).Magnitude)
                effects.caption.Text = other.DisplayName .. "\n" .. (distance and distance .. " studs" or "...")
                effects.caption.TextColor3 = color
            end
        end
    end
    for other, effects in pairs(playerEffects) do
        if not present[other] then
            if effects.highlight then effects.highlight:Destroy() end
            if effects.tag then effects.tag:Destroy() end
            playerEffects[other] = nil
        end
    end
end
define("highlights", updatePlayers, function() clearPlayerEffects("highlight") end)
define("nameplates", updatePlayers, function() clearPlayerEffects("tag") end)

local function spectate()
    assert(selectedPlayer and selectedPlayer.Parent == Players, "Pilih pemain terlebih dahulu")
    local model = selectedPlayer.Character
    local target = model and model:FindFirstChildOfClass("Humanoid")
    if target and workspace.CurrentCamera then
        put("spectate", workspace.CurrentCamera, "CameraType", Enum.CameraType.Custom)
        put("spectate", workspace.CurrentCamera, "CameraSubject", target)
    end
end
define("spectate", spectate, function()
    release("spectate")
    local camera = workspace.CurrentCamera
    if camera and humanoid and (not camera.CameraSubject or not camera.CameraSubject.Parent) then
        camera.CameraSubject = humanoid
    end
end)

gui = new("ScreenGui", {
    Name = "NebulaUltra", ResetOnSpawn = false, IgnoreGuiInset = true,
    DisplayOrder = 1000, ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
}, player:WaitForChild("PlayerGui"))
panel = new("Frame", {
    AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5),
    Size = UDim2.fromOffset(680, 530), BackgroundColor3 = Color3.fromRGB(19, 17, 29),
    BorderSizePixel = 0, Active = true,
}, gui)
round(panel, 18)
colored(new("UIStroke", { Thickness = 1.2, Transparency = 0.3 }, panel), "Color")
new("UIGradient", {
    Rotation = 110,
    Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(175, 163, 207)),
}, panel)
scaleObject = new("UIScale", {}, panel)

local function text(parent, content, size, position, fontSize)
    return new("TextLabel", {
        Text = content, Size = size, Position = position or UDim2.new(),
        BackgroundTransparency = 1, TextColor3 = textColor,
        Font = Enum.Font.Gotham, TextSize = fontSize or 12,
        TextXAlignment = Enum.TextXAlignment.Left,
    }, parent)
end

local function button(parent, content, size, position)
    local object = new("TextButton", {
        Text = content, Size = size, Position = position or UDim2.new(),
        BackgroundColor3 = surface, BorderSizePixel = 0,
        TextColor3 = textColor, Font = Enum.Font.GothamMedium, TextSize = 12,
    }, parent)
    round(object, 9)
    return object
end

local header = new("Frame", {
    Size = UDim2.new(1, -112, 0, 72), BackgroundTransparency = 1, Active = true,
}, panel)
local heading = text(header, "NEBULA ULTRA", UDim2.new(1, -24, 0, 36), UDim2.fromOffset(22, 10), 24)
heading.Font = Enum.Font.GothamBold
colored(text(header, "CLIENT CONTROL CENTER", UDim2.new(1, -24, 0, 18), UDim2.fromOffset(23, 45), 10), "TextColor3")
local minimize = button(panel, "—", UDim2.fromOffset(34, 32), UDim2.new(1, -94, 0, 20))
local close = button(panel, "×", UDim2.fromOffset(34, 32), UDim2.new(1, -50, 0, 20))
launcher = button(gui, "N", UDim2.fromOffset(46, 46), UDim2.fromOffset(12, 76))
launcher.Visible = false
colored(launcher, "BackgroundColor3")
launcher.TextColor3 = Color3.fromRGB(20, 17, 30)

local sidebar = new("Frame", {
    Position = UDim2.fromOffset(16, 82), Size = UDim2.new(0, 112, 1, -132),
    BackgroundTransparency = 1,
}, panel)
local tabLayout = new("UIListLayout", {
    Padding = UDim.new(0, 8), SortOrder = Enum.SortOrder.LayoutOrder,
}, sidebar)
local search = new("TextBox", {
    Position = UDim2.fromOffset(144, 82), Size = UDim2.new(1, -160, 0, 34),
    BackgroundColor3 = surface, BorderSizePixel = 0,
    PlaceholderText = "Cari fitur / pemain di tab ini...", Text = "",
    ClearTextOnFocus = false, Font = Enum.Font.Gotham, TextSize = 12,
    TextColor3 = textColor, PlaceholderColor3 = muted,
}, panel)
round(search)
footer = text(panel, notification, UDim2.new(1, -40, 0, 26), UDim2.new(0, 20, 1, -38), 11)
footer.TextColor3 = muted
footer.TextTruncate = Enum.TextTruncate.AtEnd
toast = text(gui, "", UDim2.new(1, -32, 0, 42), UDim2.new(0, 16, 0, 18), 12)
toast.BackgroundTransparency = 0.1
toast.BackgroundColor3 = Color3.fromRGB(25, 22, 36)
toast.TextXAlignment = Enum.TextXAlignment.Center
toast.TextWrapped = true
toast.Visible = false
round(toast)

local function filterRows()
    for i = #rows, 1, -1 do
        local row = rows[i]
        if not row.object.Parent then
            table.remove(rows, i)
        else
            row.object.Visible = query == "" or row.keywords:find(query, 1, true) ~= nil
        end
    end
end

local function page(name)
    local body = new("ScrollingFrame", {
        Position = UDim2.fromOffset(144, 126), Size = UDim2.new(1, -160, 1, -178),
        BackgroundTransparency = 1, BorderSizePixel = 0,
        ScrollBarThickness = 3, CanvasSize = UDim2.new(),
        AutomaticCanvasSize = Enum.AutomaticSize.Y,
        ScrollingDirection = Enum.ScrollingDirection.Y, Visible = name == currentTab,
    }, panel)
    colored(body, "ScrollBarImageColor3")
    new("UIListLayout", { Padding = UDim.new(0, 8), SortOrder = Enum.SortOrder.LayoutOrder }, body)
    new("UIPadding", { PaddingRight = UDim.new(0, 7), PaddingBottom = UDim.new(0, 8) }, body)
    local tab = button(sidebar, name, UDim2.new(1, 0, 0, 40))
    tab.LayoutOrder = #tabs + 1
    local record = { name = name, body = body, button = tab, order = 0 }
    table.insert(tabs, record)
    connect(tab.Activated, function()
        currentTab = name
        for _, item in ipairs(tabs) do
            item.body.Visible = item.name == name
            item.button.BackgroundColor3 = item.name == name and accent:Lerp(surface, 0.55) or surface
        end
    end)
    return record
end

local function row(pageRecord, height, keywords)
    pageRecord.order = pageRecord.order + 1
    local object = new("Frame", {
        Size = UDim2.new(1, 0, 0, height), BackgroundColor3 = surface,
        BorderSizePixel = 0, LayoutOrder = pageRecord.order,
    }, pageRecord.body)
    round(object)
    table.insert(rows, { object = object, keywords = keywords:lower() })
    return object
end

local function note(pageRecord, message)
    local object = row(pageRecord, 62, message)
    local caption = text(object, message, UDim2.new(1, -24, 1, -8), UDim2.fromOffset(12, 4), 11)
    caption.TextWrapped, caption.TextColor3 = true, muted
    return caption
end

local function action(pageRecord, title, callback)
    local object = row(pageRecord, 42, title)
    local control = button(object, title, UDim2.fromScale(1, 1))
    connect(control.Activated, guarded(callback))
    return object, control
end

local function toggle(pageRecord, title, key)
    local object = row(pageRecord, 44, title)
    local control = button(object, "", UDim2.fromScale(1, 1))
    text(control, title, UDim2.new(1, -86, 1, 0), UDim2.fromOffset(12, 0), 12)
    local status = text(control, "", UDim2.fromOffset(55, 26), UDim2.new(1, -67, 0, 9), 11)
    status.TextXAlignment = Enum.TextXAlignment.Center
    status.BackgroundTransparency = 0
    round(status, 7)
    watch(key, function()
        status.Text = values[key] and "ON" or "OFF"
        status.BackgroundColor3 = values[key] and accent:Lerp(surface, 0.3) or Color3.fromRGB(52, 47, 69)
    end)
    connect(control.Activated, guarded(function()
        if features[key] then setFeature(key, not values[key])
        else values[key] = not values[key]; sync(key) end
    end))
end

local activeSlider
local function slider(pageRecord, title, key, onChange)
    local limits = bounds[key]
    local minimum, maximum, step = limits[1], limits[2], limits[3]
    local object = row(pageRecord, 70, title)
    local caption = text(object, "", UDim2.new(1, -24, 0, 26), UDim2.fromOffset(12, 2), 12)
    local minus = button(object, "−", UDim2.fromOffset(28, 28), UDim2.fromOffset(9, 34))
    local plus = button(object, "+", UDim2.fromOffset(28, 28), UDim2.new(1, -37, 0, 34))
    local track = button(object, "", UDim2.new(1, -94, 0, 28), UDim2.fromOffset(47, 34))
    track.BackgroundTransparency = 1
    local rail = new("Frame", {
        Position = UDim2.new(0, 0, 0.5, -3), Size = UDim2.new(1, 0, 0, 6),
        BackgroundColor3 = Color3.fromRGB(61, 53, 80), BorderSizePixel = 0,
    }, track)
    round(rail, 3)
    local fill = colored(new("Frame", {
        Size = UDim2.fromScale(0, 1), BorderSizePixel = 0,
    }, rail), "BackgroundColor3")
    round(fill, 3)
    watch(key, function()
        caption.Text = title .. "  ·  " .. string.format(step < 1 and "%.2f" or "%d", values[key])
        fill.Size = UDim2.fromScale((values[key] - minimum) / (maximum - minimum), 1)
    end)
    local function set(value)
        values[key] = math.clamp(math.round(value / step) * step, minimum, maximum)
        sync(key)
        if onChange then onChange() end
    end
    local function at(x)
        local ratio = (x - track.AbsolutePosition.X) / math.max(track.AbsoluteSize.X, 1)
        set(minimum + math.clamp(ratio, 0, 1) * (maximum - minimum))
    end
    connect(minus.Activated, guarded(function() set(values[key] - step) end))
    connect(plus.Activated, guarded(function() set(values[key] + step) end))
    connect(track.InputBegan, function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
            activeSlider = { input = input, at = guarded(at) }
            activeSlider.at(input.Position.X)
        end
    end)
end

local function setVisible(visible)
    panel.Visible, launcher.Visible = visible, not visible
end

local function fitPanel()
    local camera = workspace.CurrentCamera
    if not camera then return end
    local viewport = camera.ViewportSize
    if viewport.X < 48 or viewport.Y < 72 then return end
    local compact = viewport.X < 560 and viewport.Y > viewport.X
    local width, height = compact and 400 or 680, compact and 620 or 530
    panel.Size = UDim2.fromOffset(width, height)
    sidebar.Size = compact and UDim2.new(1, -32, 0, 40) or UDim2.new(0, 112, 1, -132)
    tabLayout.FillDirection = compact and Enum.FillDirection.Horizontal or Enum.FillDirection.Vertical
    for _, item in ipairs(tabs) do
        item.button.Size = compact and UDim2.new(1 / 6, -7, 0, 40) or UDim2.new(1, 0, 0, 40)
        item.button.TextSize = compact and 9 or 12
        item.body.Position = compact and UDim2.fromOffset(16, 170) or UDim2.fromOffset(144, 126)
        item.body.Size = compact and UDim2.new(1, -32, 1, -222) or UDim2.new(1, -160, 1, -178)
    end
    search.Position = compact and UDim2.fromOffset(16, 128) or UDim2.fromOffset(144, 82)
    search.Size = compact and UDim2.new(1, -32, 0, 34) or UDim2.new(1, -160, 0, 34)
    scaleObject.Scale = math.min(values.uiScale, (viewport.X - 24) / width, (viewport.Y - 48) / height)
    local halfW, halfH = width * scaleObject.Scale / 2, height * scaleObject.Scale / 2
    local x = panel.Position.X.Scale * viewport.X + panel.Position.X.Offset
    local y = panel.Position.Y.Scale * viewport.Y + panel.Position.Y.Offset
    panel.Position = UDim2.fromOffset(math.clamp(x, halfW, viewport.X - halfW), math.clamp(y, halfH, viewport.Y - halfH))
end

local function applyTheme()
    accent = themes[values.theme] or themes.Purple
    for _, binding in ipairs(accentBindings) do
        if binding[1].Parent then binding[1][binding[2]] = accent end
    end
    for key in pairs(widgets) do sync(key) end
    for _, item in ipairs(tabs) do
        item.button.BackgroundColor3 = item.name == currentTab and accent:Lerp(surface, 0.55) or surface
    end
end

local movePage = page("Move")
toggle(movePage, "Custom walk speed", "speed")
slider(movePage, "Walk speed", "walkSpeed", function() refreshFeature("speed") end)
toggle(movePage, "Custom jump", "jump")
slider(movePage, "Jump power", "jumpPower", function() refreshFeature("jump") end)
toggle(movePage, "Flight", "fly")
slider(movePage, "Flight speed", "flySpeed")
toggle(movePage, "Noclip", "noclip")
toggle(movePage, "Infinite jump", "airJump")
note(movePage, "Flight: WASD / thumbstick, Space = naik, Ctrl = turun. Mobile: UP/DOWN. Keluar dari kursi terlebih dahulu.")

local visualPage = page("Visual")
toggle(visualPage, "Fullbright", "fullbright")
toggle(visualPage, "Clear distance fog", "clearFog")
toggle(visualPage, "Night vision tint", "nightVision")
toggle(visualPage, "Disable blur / depth of field", "noBlur")
toggle(visualPage, "Custom local time", "customTime")
slider(visualPage, "Time of day", "clockTime", function() refreshFeature("customTime") end)
toggle(visualPage, "Custom camera FOV", "fov")
slider(visualPage, "Field of view", "fieldOfView", function() refreshFeature("fov") end)
toggle(visualPage, "Extended zoom distance", "zoom")
slider(visualPage, "Maximum zoom", "zoomDistance", function() refreshFeature("zoom") end)
toggle(visualPage, "Hide own character locally", "invisibleSelf")
note(visualPage, "Hide self hanya mengubah tampilan di perangkatmu. Pemain lain tetap dapat melihat karaktermu. Clear fog tidak menghapus Atmosphere.")

local playersPage = page("Players")
toggle(playersPage, "Player highlights", "highlights")
toggle(playersPage, "Names + distance", "nameplates")
toggle(playersPage, "Spectate selected player", "spectate")
local selectedInfo = note(playersPage, "Belum ada pemain dipilih. Daftar pemain ada di bawah.")

local function goTo(cframe)
    assert(liveRoot(), "Karakter belum siap")
    assert(not humanoid.Sit, "Keluar dari kursi terlebih dahulu")
    lastPosition = root.CFrame
    root.CFrame = cframe
    root.AssemblyLinearVelocity = Vector3.zero
    root.AssemblyAngularVelocity = Vector3.zero
    notify("Perpindahan diterapkan lokal; server dapat mengembalikannya.")
end

action(playersPage, "Go to selected player", function()
    local model = selectedPlayer and selectedPlayer.Character
    local target = model and model:FindFirstChild("HumanoidRootPart")
    assert(target, "Pilih pemain dengan karakter aktif")
    goTo(target.CFrame * CFrame.new(3, 0, 0))
end)
local playerRows = {}
local playerRowConnections = {}
local function clearPlayerRows()
    for _, connection in ipairs(playerRowConnections) do connection:Disconnect() end
    table.clear(playerRowConnections)
    for _, object in ipairs(playerRows) do object:Destroy() end
    table.clear(playerRows)
end
local function rebuildPlayerList()
    clearPlayerRows()
    local others = Players:GetPlayers()
    table.sort(others, function(a, b) return a.Name:lower() < b.Name:lower() end)
    for _, other in ipairs(others) do
        if other ~= player then
            local title = other.DisplayName .. "  (@" .. other.Name .. ")"
            local object = row(playersPage, 42, title)
            local control = button(object, title, UDim2.fromScale(1, 1))
            local connection = control.Activated:Connect(guarded(function()
                selectedPlayer = other
                if values.spectate then refreshFeature("spectate") end
                notify("Dipilih: @" .. other.Name)
            end))
            table.insert(playerRowConnections, connection)
            table.insert(playerRows, object)
        end
    end
    filterRows()
end

local placesPage = page("Places")
local slotLabels = {}
for slot = 1, 3 do
    slotLabels[slot] = note(placesPage, "Slot " .. slot .. ": kosong")
    action(placesPage, "Save position → slot " .. slot, function()
        assert(liveRoot(), "Karakter belum siap")
        savedPlaces[slot] = root.CFrame
        local p = root.Position
        slotLabels[slot].Text = string.format("Slot %d: %.0f / %.0f / %.0f", slot, p.X, p.Y, p.Z)
        notify("Posisi disimpan pada slot " .. slot)
    end)
    action(placesPage, "Return to slot " .. slot, function()
        assert(savedPlaces[slot], "Slot ini masih kosong")
        goTo(savedPlaces[slot])
    end)
end
action(placesPage, "Undo last teleport", function()
    assert(lastPosition, "Belum ada perpindahan untuk dikembalikan")
    goTo(lastPosition)
end)
action(placesPage, "Clear saved positions", function()
    table.clear(savedPlaces)
    lastPosition = nil
    for slot, caption in ipairs(slotLabels) do caption.Text = "Slot " .. slot .. ": kosong" end
    notify("Semua posisi sesi dihapus.")
end)

local function copyText(content)
    local clipboard = env.setclipboard or env.toclipboard or setclipboard or toclipboard
    if type(clipboard) == "function" then clipboard(content); notify("Teks disalin ke clipboard.")
    else notify(content) end
end
action(placesPage, "Copy current coordinates", function()
    assert(liveRoot(), "Karakter belum siap")
    local p = root.Position
    copyText(string.format("Vector3.new(%.2f, %.2f, %.2f)", p.X, p.Y, p.Z))
end)
note(placesPage, "Bookmark hanya disimpan dalam sesi ini. Profile tidak menyimpan posisi atau melakukan teleport otomatis.")

-- Validate imported JSON against a whitelist; never execute profile content.
local function sanitize(raw)
    assert(type(raw) == "table", "Profile harus berupa objek JSON")
    local clean = table.clone(defaults)
    for key, default in pairs(defaults) do
        local value = raw[key]
        if type(value) == type(default) then
            if type(default) == "number" then
                if value == value and math.abs(value) < math.huge then
                    local limit = bounds[key]
                    clean[key] = math.clamp(math.round(value / limit[3]) * limit[3], limit[1], limit[2])
                end
            elseif key == "theme" then
                if themes[value] then clean[key] = value end
            else clean[key] = value end
        end
    end
    return clean
end

local function applyProfile(raw)
    local clean = sanitize(raw)
    for key in pairs(features) do setFeature(key, false) end
    for key, value in pairs(clean) do if not features[key] then values[key] = value end end
    for key in pairs(features) do if clean[key] then setFeature(key, true) end end
    for key in pairs(widgets) do sync(key) end
    fitPanel()
    applyTheme()
end

local function fileFunction(name)
    local fn = env[name]
    assert(type(fn) == "function", "Executor tidak menyediakan " .. name .. "; gunakan session profile")
    return fn
end
local profilesPage = page("Profiles")
action(profilesPage, "Save profile in this session", function()
    sessionProfile = table.clone(values)
    notify("Profile sesi disimpan.")
end)
action(profilesPage, "Load session profile", function()
    assert(sessionProfile, "Belum ada profile sesi")
    applyProfile(sessionProfile)
    notify("Profile sesi dimuat.")
end)
for slot = 1, 2 do
    local path = "NebulaUltraProfile" .. slot .. ".json"
    action(profilesPage, "Save JSON profile " .. slot .. " (optional)", function()
        fileFunction("writefile")(path, Http:JSONEncode(values))
        notify("Profile tersimpan: " .. path)
    end)
    action(profilesPage, "Load JSON profile " .. slot .. " (optional)", function()
        local encoded = fileFunction("readfile")(path)
        assert(type(encoded) == "string" and #encoded <= 32768, "Profile tidak valid atau terlalu besar")
        applyProfile(Http:JSONDecode(encoded))
        notify("Profile dimuat: " .. path)
    end)
end
action(profilesPage, "Reset all settings to defaults", function()
    applyProfile(defaults)
    notify("Pengaturan default dipulihkan.")
end)
note(profilesPage, "File profile hanya memuat pengaturan panel. Tanpa API file, profile sesi tetap tersedia. Tidak ada autoload atau kode remote.")

local settingsPage = page("Settings")
toggle(settingsPage, "FPS / ping / health / XYZ", "stats")
slider(settingsPage, "UI scale", "uiScale", fitPanel)
for _, theme in ipairs({ "Purple", "Cyan", "Emerald", "Rose" }) do
    action(settingsPage, "Theme: " .. theme, function() values.theme = theme; applyTheme() end)
end
action(settingsPage, "Center panel", function() panel.Position = UDim2.fromScale(0.5, 0.5); fitPanel() end)
action(settingsPage, "Minimize panel", function() setVisible(false) end)
action(settingsPage, "Copy experience / server info", function()
    copyText("PlaceId: " .. game.PlaceId .. " | JobId: " .. game.JobId)
end)
note(settingsPage, "RightShift = buka/tutup. × = unload. God mode server tidak tersedia; script ini tidak melewati anti-cheat atau mengubah health server.")

flightPad = new("Frame", {
    Position = UDim2.new(1, -80, 0.5, -60), Size = UDim2.fromOffset(64, 118),
    BackgroundTransparency = 1, Visible = false,
}, gui)
local upButton = button(flightPad, "UP", UDim2.fromOffset(64, 52))
local downButton = button(flightPad, "DOWN", UDim2.fromOffset(64, 52), UDim2.fromOffset(0, 62))
local function hold(control, direction)
    connect(control.InputBegan, function(input)
        if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
            pointerHolds[input] = direction
            if direction == "up" then upHeld = true else downHeld = true end
        end
    end)
end
hold(upButton, "up")
hold(downButton, "down")
connect(minimize.Activated, function() setVisible(false) end)
connect(launcher.Activated, function() setVisible(true); fitPanel() end)
connect(search:GetPropertyChangedSignal("Text"), function()
    query = search.Text:lower()
    filterRows()
end)

local drag
connect(header.InputBegan, function(input)
    if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
        drag = { input = input, position = panel.Position, origin = input.Position }
    end
end)
local function matches(input, start)
    return input == start or (start.UserInputType == Enum.UserInputType.MouseButton1
        and input.UserInputType == Enum.UserInputType.MouseMovement)
end
connect(Input.InputChanged, function(input)
    if activeSlider and matches(input, activeSlider.input) then activeSlider.at(input.Position.X)
    elseif drag and matches(input, drag.input) then
        local delta = input.Position - drag.origin
        panel.Position = UDim2.new(drag.position.X.Scale, drag.position.X.Offset + delta.X,
            drag.position.Y.Scale, drag.position.Y.Offset + delta.Y)
    end
end)
connect(Input.InputEnded, function(input)
    if activeSlider and input == activeSlider.input then activeSlider = nil end
    if drag and input == drag.input then drag = nil; fitPanel() end
    pointerHolds[input] = nil
    upHeld, downHeld = false, false
    for _, direction in pairs(pointerHolds) do
        if direction == "up" then upHeld = true else downHeld = true end
    end
end)
connect(Input.InputBegan, function(input, processed)
    if not processed and not Input:GetFocusedTextBox() and input.KeyCode == Enum.KeyCode.RightShift then
        setVisible(not panel.Visible)
    end
end)
connect(Input.WindowFocusReleased, function()
    focused, drag, activeSlider = false, nil, nil
    upHeld, downHeld = false, false
    table.clear(pointerHolds)
    if activeFlight then activeFlight.velocity.VectorVelocity = Vector3.zero end
end)
connect(Input.WindowFocused, function() focused = true end)
connect(Input.JumpRequest, function()
    if values.airJump and not values.fly and liveRoot() then
        humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
    end
end)

local characterOwners = { "speed", "jump", "noclip", "invisibleSelf" }
local function clearCharacter()
    generation = generation + 1
    stopFlight()
    for _, owner in ipairs(characterOwners) do release(owner) end
    character, humanoid, root = nil, nil, nil
end
local function bindCharacter(model)
    clearCharacter()
    local ticket = generation
    character = model
    task.spawn(function()
        local h = model:WaitForChild("Humanoid", 15)
        local r = model:WaitForChild("HumanoidRootPart", 15)
        if not alive or ticket ~= generation or not h or not r then return end
        humanoid, root = h, r
        for _, key in ipairs({ "speed", "jump", "invisibleSelf", "fly" }) do
            if values[key] then
                local ok, err = pcall(features[key].enable)
                if not ok then setFeature(key, false); notify(tostring(err)) end
            end
        end
    end)
end
connect(player.CharacterAdded, bindCharacter)
connect(player.CharacterRemoving, function(model) if model == character then clearCharacter() end end)
connect(Players.PlayerAdded, function() rebuildPlayerList() end)
connect(Players.PlayerRemoving, function(other)
    if selectedPlayer == other then
        setFeature("spectate", false)
        selectedPlayer = nil
        notify("Pemain terpilih meninggalkan server.")
    end
    task.defer(function() if alive then rebuildPlayerList() end end)
end)
connect(workspace:GetPropertyChangedSignal("CurrentCamera"), function()
    release("fov")
    release("spectate")
    refreshFeature("fov")
    if values.spectate then pcall(spectate) end
    fitPanel()
end)

connect(Run.PreSimulation, function()
    if values.noclip and liveRoot() then
        for _, part in ipairs(character:GetDescendants()) do
            if part:IsA("BasePart") then put("noclip", part, "CanCollide", false) end
        end
    end
end)

local frames, elapsed, refreshElapsed, fps = 0, 0, 0, 0
local viewport = Vector2.zero
local function flightStep()
    if not activeFlight then return end
    if not values.fly or not liveRoot() then stopFlight(); return end
    local camera = workspace.CurrentCamera
    if not camera then activeFlight.velocity.VectorVelocity = Vector3.zero; return end
    local direction = humanoid.MoveDirection
    if focused and not Input:GetFocusedTextBox() then
        local x, z = 0, 0
        if Input:IsKeyDown(Enum.KeyCode.D) then x = x + 1 end
        if Input:IsKeyDown(Enum.KeyCode.A) then x = x - 1 end
        if Input:IsKeyDown(Enum.KeyCode.W) then z = z + 1 end
        if Input:IsKeyDown(Enum.KeyCode.S) then z = z - 1 end
        if x ~= 0 or z ~= 0 then direction = camera.CFrame.RightVector * x + camera.CFrame.LookVector * z end
        local rise, fall = upHeld and 1 or 0, downHeld and 1 or 0
        if Input:IsKeyDown(Enum.KeyCode.Space) then rise = 1 end
        if Input:IsKeyDown(Enum.KeyCode.LeftControl) or Input:IsKeyDown(Enum.KeyCode.RightControl) then fall = 1 end
        direction = direction + Vector3.yAxis * (rise - fall)
    else direction = Vector3.zero end
    if direction.Magnitude > 1 then direction = direction.Unit end
    activeFlight.velocity.VectorVelocity = direction * values.flySpeed
    local look = camera.CFrame.LookVector
    local flat = Vector3.new(look.X, 0, look.Z)
    if flat.Magnitude > 0.001 then activeFlight.orientation.CFrame = CFrame.lookAt(Vector3.zero, flat) end
end

connect(Run.RenderStepped, function(dt)
    flightStep()
    local camera = workspace.CurrentCamera
    if camera and camera.ViewportSize ~= viewport then viewport = camera.ViewportSize; fitPanel() end
    frames, elapsed, refreshElapsed = frames + 1, elapsed + dt, refreshElapsed + dt
    if elapsed >= 0.5 then fps = math.floor(frames / elapsed + 0.5); frames, elapsed = 0, 0 end
    if refreshElapsed < 0.5 then return end
    refreshElapsed = 0
    if values.highlights or values.nameplates or next(playerEffects) then updatePlayers() end
    if values.noBlur then removeBlur() end
    if values.invisibleSelf then hideSelf() end
    if values.spectate then pcall(spectate) end
    if selectedPlayer then
        local model = selectedPlayer.Character
        local h = model and model:FindFirstChildOfClass("Humanoid")
        selectedInfo.Text = "@" .. selectedPlayer.Name .. " | HP " .. (h and math.floor(h.Health) or "-")
    else selectedInfo.Text = "Belum ada pemain dipilih. Daftar pemain ada di bawah." end
    if os.clock() >= notificationUntil then
        toast.Visible = false
        if values.stats and liveRoot() then
            local ping = "-"
            pcall(function() ping = tostring(math.floor(Stats.Network.ServerStatsItem["Data Ping"]:GetValue())) end)
            local p = root.Position
            footer.Text = string.format("%d FPS | %s ms | HP %.0f | XYZ %.0f / %.0f / %.0f", fps, ping, humanoid.Health, p.X, p.Y, p.Z)
        else footer.Text = "NEBULA ULTRA | RightShift = buka/tutup | × = unload" end
    end
end)

local api = {}
function api.Destroy()
    if not alive then return end
    alive = false
    generation = generation + 1
    for _, connection in ipairs(connections) do connection:Disconnect() end
    table.clear(connections)
    clearPlayerRows()
    pcall(stopFlight)
    pcall(features.spectate.disable)
    if nightEffect then nightEffect:Destroy(); nightEffect = nil end
    restoreAll()
    effectFolder:Destroy()
    gui:Destroy()
    if env.__NEBULA_PANEL == api then env.__NEBULA_PANEL = nil end
end
env.__NEBULA_PANEL = api
connect(close.Activated, api.Destroy)
connect(gui.Destroying, api.Destroy)

rebuildPlayerList()
applyTheme()
fitPanel()
if player.Character then bindCharacter(player.Character) end
notify("NEBULA ULTRA aktif. RightShift = buka/tutup.")
