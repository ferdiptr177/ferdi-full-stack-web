-- Limited in-memory API model for lifecycle tests, not a Roblox emulator.
-- Invalidate cached table-global imports: real Roblox instances are userdata.
local executionEnvironment = getfenv(0)
local MOCK = { errors = {}, keys = {}, instances = {}, clock = 0 }
local function signal()
    local s = { listeners = {} }
    function s:Connect(callback)
        local connection = { Connected = true, callback = callback }
        function connection:Disconnect() self.Connected = false end
        table.insert(self.listeners, connection)
        return connection
    end
    function s:Fire(...)
        for _, connection in ipairs(table.clone(self.listeners)) do
            if connection.Connected then
                local ok, err = pcall(connection.callback, ...)
                if not ok then table.insert(MOCK.errors, tostring(err)) end
            end
        end
    end
    return s
end

local vectorMethods = {}
local vectorMeta = {}
function vectorMeta.__index(v, key)
    if key == "Magnitude" then return math.sqrt(v.X ^ 2 + v.Y ^ 2 + v.Z ^ 2) end
    if key == "Unit" then local m = v.Magnitude; return m > 0 and v / m or Vector3.zero end
    return vectorMethods[key]
end
function vectorMeta.__add(a, b) return Vector3.new(a.X + b.X, a.Y + b.Y, a.Z + b.Z) end
function vectorMeta.__sub(a, b) return Vector3.new(a.X - b.X, a.Y - b.Y, a.Z - b.Z) end
function vectorMeta.__unm(a) return Vector3.new(-a.X, -a.Y, -a.Z) end
function vectorMeta.__mul(a, b)
    if type(a) == "number" then a, b = b, a end
    return Vector3.new(a.X * b, a.Y * b, a.Z * b)
end
function vectorMeta.__div(a, b) return Vector3.new(a.X / b, a.Y / b, a.Z / b) end
function vectorMeta.__eq(a, b) return a.X == b.X and a.Y == b.Y and a.Z == b.Z end
Vector3 = { new = function(x, y, z) return setmetatable({ X = x or 0, Y = y or 0, Z = z or 0 }, vectorMeta) end }
Vector3.zero, Vector3.yAxis = Vector3.new(), Vector3.new(0, 1, 0)
Vector2 = { new = function(x, y) return Vector3.new(x or 0, y or 0, 0) end }
Vector2.zero = Vector2.new()
local frameMethods, frameMeta = {}, {}
local function frame(position, pitch, yaw)
    return setmetatable({ Position = position, pitch = pitch or 0, yaw = yaw or 0 }, frameMeta)
end
function frameMeta.__index(f, key)
    if key == "Rotation" then return frame(Vector3.zero, f.pitch, f.yaw) end
    if key == "LookVector" then return Vector3.new(-math.sin(f.yaw) * math.cos(f.pitch), math.sin(f.pitch), -math.cos(f.yaw) * math.cos(f.pitch)) end
    if key == "RightVector" then return Vector3.new(math.cos(f.yaw), 0, -math.sin(f.yaw)) end
    return frameMethods[key]
end
function frameMeta.__mul(a, b) return frame(a.Position + a:VectorToWorldSpace(b.Position), a.pitch + b.pitch, a.yaw + b.yaw) end
function frameMethods:ToOrientation() return self.pitch, self.yaw, 0 end
function frameMethods:VectorToWorldSpace(v)
    local cp, sp, cy, sy = math.cos(self.pitch), math.sin(self.pitch), math.cos(self.yaw), math.sin(self.yaw)
    return Vector3.new(cy * v.X + sy * sp * v.Y + sy * cp * v.Z, cp * v.Y - sp * v.Z,
        -sy * v.X + cy * sp * v.Y + cy * cp * v.Z)
end
function frameMethods:VectorToObjectSpace(v)
    local cp, sp, cy, sy = math.cos(self.pitch), math.sin(self.pitch), math.cos(self.yaw), math.sin(self.yaw)
    return Vector3.new(cy * v.X - sy * v.Z, sy * sp * v.X + cp * v.Y + cy * sp * v.Z,
        sy * cp * v.X - sp * v.Y + cy * cp * v.Z)
end
function frameMethods:Lerp(other, alpha)
    return frame(self.Position + (other.Position - self.Position) * alpha,
        self.pitch + (other.pitch - self.pitch) * alpha, self.yaw + (other.yaw - self.yaw) * alpha)
end
CFrame = {}
function CFrame.new(x, y, z) return frame(type(x) == "table" and x or Vector3.new(x, y, z)) end
function CFrame.fromOrientation(x, y) return frame(Vector3.zero, x, y) end
function CFrame.lookAt(position, target)
    local d = (target - position).Unit
    return frame(position, math.asin(d.Y), math.atan2(-d.X, -d.Z))
end
UDim = { new = function(scale, offset) return { Scale = scale or 0, Offset = offset or 0 } end }
UDim2 = {}
function UDim2.new(xs, xo, ys, yo) return { X = UDim.new(xs, xo), Y = UDim.new(ys, yo) } end
function UDim2.fromOffset(x, y) return UDim2.new(0, x, 0, y) end
function UDim2.fromScale(x, y) return UDim2.new(x, 0, y, 0) end
local colorMethods = {}
Color3 = {}
function Color3.new(r, g, b) return setmetatable({ R = r, G = g, B = b }, { __index = colorMethods }) end
function Color3.fromRGB(r, g, b) return Color3.new(r / 255, g / 255, b / 255) end
function Color3.fromHSV(h, s, v) return Color3.new(h, s, v) end
function colorMethods:Lerp(other, alpha)
    return Color3.new(self.R + (other.R - self.R) * alpha, self.G + (other.G - self.G) * alpha, self.B + (other.B - self.B) * alpha)
end
ColorSequence = { new = function(a, b) return { a, b } end }
Enum = setmetatable({}, { __index = function(t, group)
    local items = setmetatable({}, { __index = function(s, name) rawset(s, name, group .. "." .. name); return rawget(s, name) end })
    rawset(t, group, items)
    return items
end })
RaycastParams = { new = function() return {} end }

local methods = {}
local signalNames = {
    Activated = true, InputBegan = true, InputChanged = true, InputEnded = true,
    Destroying = true, CharacterAdded = true, CharacterRemoving = true,
    PlayerAdded = true, PlayerRemoving = true, PreSimulation = true,
    RenderStepped = true, WindowFocused = true, WindowFocusReleased = true,
    JumpRequest = true, Blocked = true,
}
local instanceMeta = {}
function instanceMeta.__index(object, key)
    if key == "Parent" then return rawget(object, "_parent") end
    if key == "Position" and object:IsA("BasePart") then return object._properties.CFrame.Position end
    if methods[key] then return methods[key] end
    if signalNames[key] then
        if not object._signals[key] then object._signals[key] = signal() end
        return object._signals[key]
    end
    return object._properties[key]
end
function instanceMeta.__newindex(object, key, value)
    if key == "Parent" then
        local old = rawget(object, "_parent")
        if old then for i, child in ipairs(old._children) do if child == object then table.remove(old._children, i); break end end end
        rawset(object, "_parent", value)
        if value then table.insert(value._children, object) end
    else
        local old = object._properties[key]
        object._properties[key] = value
        if old ~= value and object._propertySignals[key] then object._propertySignals[key]:Fire() end
    end
end
Instance = {}
function Instance.new(class)
    local object = setmetatable({ _properties = {
        ClassName = class, Name = class, Text = "", TextSize = 12,
        CFrame = CFrame.new(), Size = Vector3.new(2, 2, 1),
        CanCollide = true, Anchored = false, LocalTransparencyModifier = 0,
        AssemblyLinearVelocity = Vector3.zero, AssemblyAngularVelocity = Vector3.zero,
        ViewportSize = Vector2.new(1280, 720), FieldOfView = 70,
        CameraType = Enum.CameraType.Custom, AbsoluteSize = Vector2.new(200, 40),
        AbsolutePosition = Vector2.zero, Health = 100, MaxHealth = 100,
        WalkSpeed = 16, JumpPower = 50, JumpHeight = 7.2, HipHeight = 2,
        AutoRotate = true, PlatformStand = false, Sit = false,
        FloorMaterial = Enum.Material.Air,
    }, _signals = {}, _propertySignals = {}, _children = {} }, instanceMeta)
    table.insert(MOCK.instances, object)
    return object
end
function methods:IsA(class) return self.ClassName == class or (class == "BasePart" and (self.ClassName == "Part" or self.ClassName == "MeshPart")) end
function methods:GetChildren() return table.clone(self._children) end
function methods:GetDescendants()
    local result = {}
    for _, child in ipairs(self._children) do
        table.insert(result, child)
        for _, nested in ipairs(child:GetDescendants()) do table.insert(result, nested) end
    end
    return result
end
function methods:FindFirstChild(name) for _, child in ipairs(self._children) do if child.Name == name then return child end end end
function methods:FindFirstChildOfClass(class) for _, child in ipairs(self._children) do if child:IsA(class) then return child end end end
function methods:WaitForChild(name) return self:FindFirstChild(name) end
function methods:GetPropertyChangedSignal(key)
    if not self._propertySignals[key] then self._propertySignals[key] = signal() end
    return self._propertySignals[key]
end
function methods:Destroy()
    if rawget(self, "_destroyed") then return end
    rawset(self, "_destroyed", true)
    self.Destroying:Fire()
    for _, child in ipairs(self:GetChildren()) do child:Destroy() end
    self.Parent = nil
end
function methods:ChangeState(state) self.LastState = state end
function methods:MoveTo(position)
    local r = self.Parent and self.Parent:FindFirstChild("HumanoidRootPart")
    if r then r.CFrame = CFrame.new(position) end
end

workspace = Instance.new("Workspace")
workspace.Gravity, workspace.Name = 196.2, "Workspace"
local camera = Instance.new("Camera")
camera.CFrame, camera.Parent = CFrame.new(0, 10, 20), workspace
workspace.CurrentCamera = camera
function workspace:Raycast() return nil end
local services = { Workspace = workspace }
game = { PlaceId = 12345, JobId = "mock-job" }
function game:GetService(name)
    if not services[name] then services[name] = Instance.new(name) end
    return services[name]
end
local players = game:GetService("Players")
local localPlayer = Instance.new("Player")
localPlayer.Name, localPlayer.DisplayName, localPlayer.UserId, localPlayer.Parent = "Local", "Local", 1, players
localPlayer.CameraMaxZoomDistance = 128
local playerGui = Instance.new("PlayerGui")
playerGui.Parent = localPlayer
players.LocalPlayer = localPlayer
local other = Instance.new("Player")
other.Name, other.DisplayName, other.UserId, other.Parent = "Other", "Other", 2, players
function players:GetPlayers() return { localPlayer, other } end
function MOCK.character(name)
    local model = Instance.new("Model")
    model.Name, model.Parent = name, workspace
    local h = Instance.new("Humanoid"); h.Parent = model
    local r = Instance.new("Part"); r.Name, r.CFrame, r.Parent = "HumanoidRootPart", CFrame.new(0, 10, 0), model
    local head = Instance.new("Part"); head.Name, head.Parent = "Head", model
    return model
end
localPlayer.Character, other.Character = MOCK.character("LocalCharacter"), MOCK.character("OtherCharacter")
camera.CameraSubject = localPlayer.Character:FindFirstChildOfClass("Humanoid")
local lighting = game:GetService("Lighting")
lighting.Brightness, lighting.ClockTime, lighting.GlobalShadows, lighting.FogEnd = 1, 9, true, 500
lighting.Ambient, lighting.OutdoorAmbient = Color3.fromRGB(50, 50, 50), Color3.fromRGB(70, 70, 70)
lighting.ExposureCompensation = 0
local input = game:GetService("UserInputService")
function input:GetFocusedTextBox() return nil end
function input:IsKeyDown(key) return MOCK.keys[key] == true end
function input:IsMouseButtonPressed() return false end
function input:GetMouseDelta() return Vector2.zero end
local stats = game:GetService("Stats")
stats.Network = { ServerStatsItem = { ["Data Ping"] = { GetValue = function() return 45 end } } }
local pathfinding = game:GetService("PathfindingService")
function pathfinding:CreatePath()
    local path = Instance.new("Path")
    path.Status = Enum.PathStatus.Success
    function path:ComputeAsync(origin, target) self.target = target end
    function path:GetWaypoints() return { { Position = self.target, Action = "Walk" } } end
    return path
end
task = {}
function task.spawn(callback, ...)
    local ok, err = pcall(callback, ...)
    if not ok then table.insert(MOCK.errors, tostring(err)) end
end
task.defer = task.spawn
function task.wait(seconds) MOCK.clock = MOCK.clock + (seconds or 0.01); return seconds or 0.01 end
local shared = {}
function getgenv() return shared end
function MOCK.click(caption)
    for _, object in ipairs(MOCK.instances) do
        if not rawget(object, "_destroyed") and object.ClassName == "TextButton" and object.Text == caption then
            object.Activated:Fire()
            return
        end
    end
    error("Button not found: " .. caption)
end
function MOCK.assertNoErrors()
    assert(#MOCK.errors == 0, "Mock runtime callback error: " .. table.concat(MOCK.errors, "; "))
end
function MOCK.connectionCount()
    local count = 0
    for _, object in ipairs(MOCK.instances) do
        for _, group in ipairs({ object._signals, object._propertySignals }) do
            for _, s in pairs(group) do
                for _, connection in ipairs(s.listeners) do if connection.Connected then count = count + 1 end end
            end
        end
    end
    return count
end
NEBULA_MOCK = MOCK
