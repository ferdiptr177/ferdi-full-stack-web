import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const modulePath = process.env.LUAU_WEB_MODULE;
const { LuauState } = await (modulePath ? import(pathToFileURL(modulePath).href) : import('luau-web'));
const source = readFileSync(resolve(root, 'dist/NEBULA_50000.lua'), 'utf8');
const manifest = JSON.parse(readFileSync(resolve(root, 'dist/manifest.json'), 'utf8'));
const presets = JSON.parse(readFileSync(resolve(root, 'dist/presets.json'), 'utf8'));
const lines = source.split('\n').length - (source.endsWith('\n') ? 1 : 0);
if (lines !== 50000) throw new Error(`Source length is ${lines}`);
if (readFileSync(resolve(root, 'dist/NEBULA_50000.txt'), 'utf8') !== source) throw new Error('TXT differs from Lua source');
if (createHash('sha256').update(source).digest('hex') !== manifest.sha256) throw new Error('Source checksum mismatch');
if (new Set(presets.map(p => JSON.stringify(p.values))).size !== presets.length) throw new Error('Duplicate snapshots');
console.log(`PASS: ${lines} source lines, identical TXT, matching checksum, ${presets.length} distinct profiles`);

const state = await LuauState.createAsync();
try {
    state.loadstring(source, 'NEBULA_50000.lua', true);
    console.log('PASS: standalone source compiles as Luau');
    const mock = readFileSync(resolve(root, 'tests/mock-roblox.lua'), 'utf8');
    await state.loadstring(mock, 'mock-roblox.lua', true)();
    const instrumented = source + `
return {
    features=features, values=values, defaults=defaults, setFeature=setFeature,
    sanitize=sanitize, applyProfile=applyProfile, library=NEBULA_PRESETS,
    tabs=tabs, gui=gui, api=api, root=function() return root end, message=function() return notification end,
    humanoid=function() return humanoid end, props=properties, effects=playerEffects, registry=connections, rows=rows,
}
`;
    const result = await state.loadstring(instrumented, 'NEBULA_50000-instrumented', true)();
    state.env.set('PANEL', result[0], true);
    const checks = `
local mock = NEBULA_MOCK
local p = PANEL
local players = game:GetService('Players')
local player = players.LocalPlayer
local lighting = game:GetService('Lighting')
assert(#p.tabs == 14, 'expected fourteen tabs')
assert(p.root() and p.humanoid(), 'character must bind during startup')
mock.assertNoErrors()
local initialRegistry=#p.registry
local initialSignals=mock.connectionCount()
for _=1,30 do players.PlayerAdded:Fire() end
assert(#p.registry==initialRegistry and mock.connectionCount()==initialSignals,'dynamic player rows leaked event connections')
for _, record in ipairs(p.library) do
    local clean = p.sanitize(record.values)
    for key, value in pairs(record.values) do
        if type(value)=='number' then assert(math.abs(clean[key]-value)<1e-8, 'preset value altered: '..key)
        else assert(clean[key]==value, 'invalid preset field: '..key) end
    end
end
p.setFeature('speed',true)
assert(p.humanoid().WalkSpeed==32,'speed must apply')
p.setFeature('speed',false)
assert(p.humanoid().WalkSpeed==16,'speed must restore')
p.setFeature('fullbright',true)
p.values.clockTime=21
p.setFeature('customTime',true)
assert(lighting.ClockTime==21,'custom time priority')
p.setFeature('customTime',false)
assert(lighting.ClockTime==14,'fullbright should remain')
p.setFeature('fullbright',false)
assert(lighting.ClockTime==9,'original lighting must restore')
p.setFeature('invisibleSelf',true)
assert(p.root().LocalTransparencyModifier==1,'local transparency')
p.setFeature('invisibleSelf',false)
assert(p.root().LocalTransparencyModifier==0,'transparency restore')
assert(p.values.freecam==false,'freecam unexpectedly enabled before call')
p.setFeature('freecam',true)
assert(workspace.CurrentCamera.CameraType==Enum.CameraType.Scriptable,'freecam camera type: '..p.message())
mock.mouseHeld, mock.mouseDelta=true,Vector2.new(5,2)
game:GetService('RunService').RenderStepped:Fire(0.1)
assert(game:GetService('UserInputService').MouseBehavior==Enum.MouseBehavior.LockCurrentPosition,'freecam must own mouse lock')
mock.mouseHeld=false
game:GetService('UserInputService').WindowFocusReleased:Fire()
assert(game:GetService('UserInputService').MouseBehavior==Enum.MouseBehavior.Default,'mouse state must restore on focus loss')
game:GetService('UserInputService').WindowFocused:Fire()
p.setFeature('orbit',true)
assert(p.values.orbit==false and p.values.freecam==true,'invalid orbit must preserve existing freecam')
game:GetService('RunService').RenderStepped:Fire(0.5)
p.setFeature('freecam',false)
assert(workspace.CurrentCamera.CameraType==Enum.CameraType.Custom,'camera type restore')
p.setFeature('noAutoRotate',true)
p.setFeature('fly',true)
assert(p.humanoid().PlatformStand==true,'flight stand state')
p.setFeature('fly',false)
assert(p.humanoid().AutoRotate==false,'other rotation override must remain')
p.setFeature('noAutoRotate',false)
assert(p.humanoid().AutoRotate==true,'rotation must restore')
p.setFeature('freezeSelf',true)
p.setFeature('fly',true)
assert(p.values.fly==false and p.root().Anchored,'flight/freeze conflict must fail closed')
p.setFeature('freezeSelf',false)
assert(p.root().Anchored==false,'anchor must restore')
mock.click('Save position → slot 1')
mock.click('Walk path to bookmark 1')
assert(mock.controls.controlsEnabled==true,'navigation must restore enabled controls')
mock.controls.controlsEnabled=false
mock.click('Walk path to bookmark 1')
assert(mock.controls.controlsEnabled==false,'navigation must preserve previously disabled controls')
mock.controls.controlsEnabled=true
mock.click('Cancel navigation')
mock.click('Start camera recording')
game:GetService('RunService').RenderStepped:Fire(0.5)
game:GetService('RunService').RenderStepped:Fire(0.5)
mock.click('Stop camera recording')
p.setFeature('pathPlayback',true)
game:GetService('RunService').RenderStepped:Fire(0.5)
mock.click('Start camera recording')
assert(p.values.pathPlayback==false,'recording must stop playback')
game:GetService('RunService').RenderStepped:Fire(0.5)
mock.click('Stop camera recording')
mock.click('Other  (@Other)')
p.setFeature('spectate',true)
p.setFeature('spectate',false)
p.setFeature('highlights',true)
p.setFeature('nameplates',true)
game:GetService('RunService').RenderStepped:Fire(0.5)
local other=players:GetPlayers()[2]
local oldHead=other.Character:FindFirstChild('Head')
oldHead:Destroy()
local head=Instance.new('Part')
head.Name,head.Parent='Head',other.Character
game:GetService('RunService').RenderStepped:Fire(0.5)
assert(p.effects[other].tag.Adornee==head,'nameplate did not follow replaced head')
p.setFeature('nameplates',false)
game:GetService('RunService').RenderStepped:Fire(0.5)
p.setFeature('highlights',false)
-- Expansion runtime checks: visual ownership and mutually exclusive effects.
lighting.FogStart,lighting.FogColor=5,Color3.fromRGB(100,110,120)
local initialBrightness,initialFogEnd=lighting.Brightness,lighting.FogEnd
p.setFeature('fullbright',true)
p.values.sceneBrightnessValue=3
p.setFeature('sceneBrightness',true)
assert(lighting.Brightness==3,'scene brightness priority')
p.setFeature('sceneBrightness',false)
assert(lighting.Brightness==2,'scene disable must reveal fullbright')
p.setFeature('fullbright',false)
assert(lighting.Brightness==initialBrightness,'scene brightness baseline restore')
p.setFeature('clearFog',true)
p.setFeature('sceneFog',true)
assert(lighting.FogEnd==p.values.sceneFogEnd,'custom fog must win')
p.setFeature('sceneFog',false)
assert(lighting.FogEnd==1000000,'clear fog layer must remain')
p.setFeature('clearFog',false)
assert(lighting.FogEnd==initialFogEnd and lighting.FogStart==5,'fog properties must restore')
p.setFeature('noBloom',true)
p.setFeature('sceneBloom',true)
assert(p.values.sceneBloom and not p.values.noBloom,'custom bloom must disable bloom suppression')
p.setFeature('noBloom',true)
assert(not p.values.sceneBloom,'bloom suppression must disable custom bloom')
p.setFeature('noBloom',false)
p.setFeature('noBlur',true)
p.setFeature('sceneDepth',true)
assert(p.values.sceneDepth and not p.values.noBlur,'custom depth must disable blur suppression')
p.setFeature('noBlur',true)
assert(not p.values.sceneDepth,'blur suppression must disable custom depth')
p.setFeature('noBlur',false)
p.setFeature('motionTrail',true)
assert(p.root():FindFirstChild('NebulaMotionTrail'),'motion trail not created')
p.setFeature('motionTrail',false)
assert(not p.root():FindFirstChild('NebulaMotionTrail'),'trail cleanup failed')
p.setFeature('reticle',true)
p.setFeature('nearbyList',true)
p.setFeature('motionMetrics',true)
p.setFeature('letterbox',true)
game:GetService('RunService').RenderStepped:Fire(1)
assert(p.gui:FindFirstChild('NebulaReticle').Visible,'reticle overlay missing')
assert(p.gui:FindFirstChild('NebulaScout').Visible,'nearby panel missing')
assert(p.gui:FindFirstChild('NebulaMotionMetrics').Visible,'motion metrics panel missing')
assert(p.gui:FindFirstChild('NebulaLetterbox').Visible,'letterbox missing')
mock.click('Stop all features')
game:GetService('RunService').RenderStepped:Fire(0.5)
assert(not p.gui:FindFirstChild('NebulaReticle').Visible and not p.gui:FindFirstChild('NebulaScout').Visible,'stop-all left overlays active')
for _, record in ipairs(p.library) do p.applyProfile(record.values) end
p.applyProfile(p.defaults)
p.setFeature('speed',true)
p.setFeature('noAutoRotate',true)
local old = player.Character
player.CharacterRemoving:Fire(old)
old:Destroy()
player.Character=mock.character('Replacement')
player.CharacterAdded:Fire(player.Character)
assert(p.humanoid().WalkSpeed==32 and not p.humanoid().AutoRotate,'respawn must restore selected features')
local invalid=p.sanitize({walkSpeed=math.huge,uiScale=0/0,theme='invalid',speed='true',arbitrary='ignored'})
assert(invalid.walkSpeed==32 and invalid.uiScale==1 and invalid.theme=='Purple' and invalid.speed==false and invalid.arbitrary==nil,'profile sanitization')
mock.assertNoErrors()
local featureCount=0
for _ in pairs(p.features) do featureCount=featureCount+1 end
print('Runtime inventory: '..#p.tabs..' tabs, '..featureCount..' registered runtime toggles, '..#p.rows..' controls/notes')
local h=p.humanoid()
p.api.Destroy()
assert(h.WalkSpeed==16 and h.AutoRotate==true,'unload must restore character state')
assert(mock.connectionCount()==0,'unload must disconnect signals')
assert(getgenv().__NEBULA_PANEL==nil,'singleton must clear')
mock.assertNoErrors()
return 'PASS: startup, expanded tabs, player list/streaming, all presets, camera conflicts/recording, movement/lighting layers, navigation, respawn, unload'
`;
    console.log(await state.loadstring(checks, 'integration-checks', true)());
    const first = await state.loadstring(instrumented, 'reexecute-first', true)();
    const second = await state.loadstring(instrumented, 'reexecute-second', true)();
    state.env.set('FIRST_PANEL', first[0], true);
    state.env.set('SECOND_PANEL', second[0], true);
    console.log(await state.loadstring(`
assert(FIRST_PANEL.gui.Parent==nil,'rerun must destroy previous GUI')
assert(SECOND_PANEL.gui.Parent~=nil,'new GUI must exist')
SECOND_PANEL.api.Destroy()
assert(NEBULA_MOCK.connectionCount()==0,'rerun/unload leaked listeners')
NEBULA_MOCK.assertNoErrors()
return 'PASS: reexecution replaces old panel and leaves zero listeners after unload'
`, 'rerun-checks', true)());
} finally {
    state.destroy();
}
