import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const modulePath = process.env.LUAU_WEB_MODULE;
const { LuauState } = await (modulePath ? import(pathToFileURL(modulePath).href) : import('luau-web'));
const source = readFileSync(resolve(root, 'dist/NEBULA_15000.lua'), 'utf8');
const manifest = JSON.parse(readFileSync(resolve(root, 'dist/manifest.json'), 'utf8'));
const presets = JSON.parse(readFileSync(resolve(root, 'dist/presets.json'), 'utf8'));
const lines = source.split('\n').length - (source.endsWith('\n') ? 1 : 0);
if (lines !== 15000) throw new Error(`Source length is ${lines}`);
if (readFileSync(resolve(root, 'dist/NEBULA_15000.txt'), 'utf8') !== source) throw new Error('TXT differs from Lua source');
if (createHash('sha256').update(source).digest('hex') !== manifest.sha256) throw new Error('Source checksum mismatch');
if (new Set(presets.map(p => JSON.stringify(p.values))).size !== presets.length) throw new Error('Duplicate snapshots');
console.log(`PASS: ${lines} source lines, identical TXT, matching checksum, ${presets.length} distinct profiles`);

const state = await LuauState.createAsync();
try {
    state.loadstring(source, 'NEBULA_15000.lua', true);
    console.log('PASS: standalone source compiles as Luau');
    const mock = readFileSync(resolve(root, 'tests/mock-roblox.lua'), 'utf8');
    await state.loadstring(mock, 'mock-roblox.lua', true)();
    const instrumented = source + `
return {
    features=features, values=values, defaults=defaults, setFeature=setFeature,
    sanitize=sanitize, applyProfile=applyProfile, library=NEBULA_PRESETS,
    tabs=tabs, gui=gui, api=api, root=function() return root end, message=function() return notification end,
    humanoid=function() return humanoid end, props=properties,
}
`;
    const result = await state.loadstring(instrumented, 'NEBULA_15000-instrumented', true)();
    state.env.set('PANEL', result[0], true);
    const checks = `
local mock = NEBULA_MOCK
local p = PANEL
local players = game:GetService('Players')
local player = players.LocalPlayer
local lighting = game:GetService('Lighting')
assert(#p.tabs == 11, 'expected eleven tabs')
assert(p.root() and p.humanoid(), 'character must bind during startup')
mock.assertNoErrors()
for _, record in ipairs(p.library) do
    local clean = p.sanitize(record.values)
    for key, value in pairs(record.values) do
        if type(value)=='number' then assert(math.abs(clean[key]-value)<1e-8, 'preset value altered: '..key)
        else assert(clean[key]==value, 'invalid preset field: '..key) end
    end
end
p.setFeature('speed',true)
assert(p.humanoid().WalkSpeed==32,'speed must apply')
p.setFeature('speed',false)
assert(p.humanoid().WalkSpeed==16,'speed must restore')
p.setFeature('fullbright',true)
p.values.clockTime=21
p.setFeature('customTime',true)
assert(lighting.ClockTime==21,'custom time priority')
p.setFeature('customTime',false)
assert(lighting.ClockTime==14,'fullbright should remain')
p.setFeature('fullbright',false)
assert(lighting.ClockTime==9,'original lighting must restore')
p.setFeature('invisibleSelf',true)
assert(p.root().LocalTransparencyModifier==1,'local transparency')
p.setFeature('invisibleSelf',false)
assert(p.root().LocalTransparencyModifier==0,'transparency restore')
assert(p.values.freecam==false,'freecam unexpectedly enabled before call')
p.setFeature('freecam',true)
assert(workspace.CurrentCamera.CameraType==Enum.CameraType.Scriptable,'freecam camera type: '..p.message())
p.setFeature('orbit',true)
assert(p.values.orbit==false and p.values.freecam==true,'invalid orbit must preserve existing freecam')
game:GetService('RunService').RenderStepped:Fire(0.5)
p.setFeature('freecam',false)
assert(workspace.CurrentCamera.CameraType==Enum.CameraType.Custom,'camera type restore')
p.setFeature('noAutoRotate',true)
p.setFeature('fly',true)
assert(p.humanoid().PlatformStand==true,'flight stand state')
p.setFeature('fly',false)
assert(p.humanoid().AutoRotate==false,'other rotation override must remain')
p.setFeature('noAutoRotate',false)
assert(p.humanoid().AutoRotate==true,'rotation must restore')
p.setFeature('freezeSelf',true)
p.setFeature('fly',true)
assert(p.values.fly==false and p.root().Anchored,'flight/freeze conflict must fail closed')
p.setFeature('freezeSelf',false)
assert(p.root().Anchored==false,'anchor must restore')
mock.click('Save position → slot 1')
mock.click('Walk path to bookmark 1')
mock.click('Cancel navigation')
mock.click('Start camera recording')
game:GetService('RunService').RenderStepped:Fire(0.5)
game:GetService('RunService').RenderStepped:Fire(0.5)
mock.click('Stop camera recording')
p.setFeature('pathPlayback',true)
game:GetService('RunService').RenderStepped:Fire(0.5)
mock.click('Start camera recording')
assert(p.values.pathPlayback==false,'recording must stop playback')
game:GetService('RunService').RenderStepped:Fire(0.5)
mock.click('Stop camera recording')
mock.click('Other  (@Other)')
p.setFeature('spectate',true)
p.setFeature('spectate',false)
p.setFeature('highlights',true)
p.setFeature('nameplates',true)
game:GetService('RunService').RenderStepped:Fire(0.5)
p.setFeature('nameplates',false)
game:GetService('RunService').RenderStepped:Fire(0.5)
p.setFeature('highlights',false)
for _, record in ipairs(p.library) do p.applyProfile(record.values) end
p.applyProfile(p.defaults)
p.setFeature('speed',true)
p.setFeature('noAutoRotate',true)
local old = player.Character
player.CharacterRemoving:Fire(old)
old:Destroy()
player.Character=mock.character('Replacement')
player.CharacterAdded:Fire(player.Character)
assert(p.humanoid().WalkSpeed==32 and not p.humanoid().AutoRotate,'respawn must restore selected features')
local invalid=p.sanitize({walkSpeed=math.huge,uiScale=0/0,theme='invalid',speed='true',arbitrary='ignored'})
assert(invalid.walkSpeed==32 and invalid.uiScale==1 and invalid.theme=='Purple' and invalid.speed==false and invalid.arbitrary==nil,'profile sanitization')
mock.assertNoErrors()
local h=p.humanoid()
p.api.Destroy()
assert(h.WalkSpeed==16 and h.AutoRotate==true,'unload must restore character state')
assert(mock.connectionCount()==0,'unload must disconnect signals')
assert(getgenv().__NEBULA_PANEL==nil,'singleton must clear')
mock.assertNoErrors()
return 'PASS: startup, 11 tabs, all presets, camera conflicts/recording, movement/lighting layers, navigation, respawn, unload'
`;
    console.log(await state.loadstring(checks, 'integration-checks', true)());
    const first = await state.loadstring(instrumented, 'reexecute-first', true)();
    const second = await state.loadstring(instrumented, 'reexecute-second', true)();
    state.env.set('FIRST_PANEL', first[0], true);
    state.env.set('SECOND_PANEL', second[0], true);
    console.log(await state.loadstring(`
assert(FIRST_PANEL.gui.Parent==nil,'rerun must destroy previous GUI')
assert(SECOND_PANEL.gui.Parent~=nil,'new GUI must exist')
SECOND_PANEL.api.Destroy()
assert(NEBULA_MOCK.connectionCount()==0,'rerun/unload leaked listeners')
NEBULA_MOCK.assertNoErrors()
return 'PASS: reexecution replaces old panel and leaves zero listeners after unload'
`, 'rerun-checks', true)());
} finally {
    state.destroy();
}
