-- Optional overlays and local scene controls. No network or anti-cheat hooks.
return function(ctx)
    local values = ctx.values
    local new, text, round = ctx.new, ctx.text, ctx.round
    local page, note, action = ctx.page, ctx.note, ctx.action
    local toggle, slider = ctx.toggle, ctx.slider
    local ownedConnections = {}
    local cleaned = false
    local palette = {
        White = Color3.fromRGB(245, 245, 255),
        Cyan = Color3.fromRGB(70, 225, 245),
        Rose = Color3.fromRGB(255, 110, 165),
        Lime = Color3.fromRGB(165, 245, 85),
    }

    local function listen(signal, callback)
        local connection = ctx.connect(signal, ctx.guarded(callback))
        table.insert(ownedConnections, connection)
        return connection
    end

    local function rootReady()
        local root, humanoid = ctx.getRoot(), ctx.getHumanoid()
        if root and root.Parent and humanoid and humanoid.Health > 0 then return root, humanoid end
    end

    local function sceneColor()
        return Color3.fromRGB(values.sceneRed, values.sceneGreen, values.sceneBlue)
    end

    local overlay = new("Frame", {
        Name = "NebulaReticle", Size = UDim2.fromScale(1, 1),
        BackgroundTransparency = 1, Visible = false, ZIndex = 0,
    }, ctx.gui)
    local bars = {}
    for index = 1, 4 do
        bars[index] = new("Frame", {
            BorderSizePixel = 0, AnchorPoint = Vector2.new(0.5, 0.5), ZIndex = 0,
        }, overlay)
        round(bars[index], 2)
    end
    local dot = new("Frame", {
        AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5),
        BorderSizePixel = 0, ZIndex = 0,
    }, overlay)
    round(dot, 10)
    local ring = new("Frame", {
        AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5),
        BackgroundTransparency = 1, ZIndex = 0,
    }, overlay)
    round(ring, 100)
    local ringStroke = new("UIStroke", { Thickness = 1 }, ring)
    local targetCaption = text(overlay, "", UDim2.fromOffset(320, 42), UDim2.new(0.5, -160, 0.5, 55), 11)
    targetCaption.TextXAlignment = Enum.TextXAlignment.Center
    targetCaption.TextWrapped, targetCaption.ZIndex = true, 0
    ctx.define("reticle", function()
        overlay.Visible = true
    end, function()
        overlay.Visible = false
    end)

    local reticlePage = page("Reticle")
    toggle(reticlePage, "Center crosshair", "reticle")
    toggle(reticlePage, "Center dot", "reticleDot")
    toggle(reticlePage, "Outer ring", "reticleRing")
    toggle(reticlePage, "Expand gap with movement", "reticleDynamic")
    toggle(reticlePage, "Surface name / distance", "reticleTargetInfo")
    slider(reticlePage, "Crosshair length", "reticleSize")
    slider(reticlePage, "Crosshair gap", "reticleGap")
    slider(reticlePage, "Crosshair thickness", "reticleThickness")
    slider(reticlePage, "Crosshair opacity", "reticleOpacity")
    slider(reticlePage, "Surface ray distance", "reticleRayDistance")
    for _, name in ipairs({ "White", "Cyan", "Rose", "Lime" }) do
        action(reticlePage, "Crosshair color: " .. name, function()
            values.reticleColor = name
            ctx.notify("Crosshair: " .. name)
        end)
    end
    note(reticlePage, "Crosshair adalah overlay visual. Tidak mengarahkan aim, mengubah peluru, atau menjamin hit. Info permukaan memakai raycast arah kamera.")

    local scoutPanel = new("Frame", {
        Name = "NebulaScout", Position = UDim2.new(1, -272, 0, 76),
        Size = UDim2.fromOffset(256, 236), BackgroundColor3 = Color3.fromRGB(23, 21, 34),
        BackgroundTransparency = 0.12, Visible = false,
    }, ctx.gui)
    round(scoutPanel)
    text(scoutPanel, "NEARBY PLAYERS", UDim2.new(1, -20, 0, 24), UDim2.fromOffset(10, 5), 12)
    local nearbyCaption = text(scoutPanel, "", UDim2.new(1, -20, 1, -36), UDim2.fromOffset(10, 30), 11)
    nearbyCaption.TextYAlignment = Enum.TextYAlignment.Top
    nearbyCaption.TextWrapped = true
    local motionPanel = new("Frame", {
        Name = "NebulaMotionMetrics", Position = UDim2.new(0, 16, 0, 76),
        Size = UDim2.fromOffset(250, 110), BackgroundColor3 = Color3.fromRGB(23, 21, 34),
        BackgroundTransparency = 0.12, Visible = false,
    }, ctx.gui)
    round(motionPanel)
    local motionCaption = text(motionPanel, "", UDim2.new(1, -20, 1, -12), UDim2.fromOffset(10, 6), 11)
    motionCaption.TextWrapped = true
    motionCaption.TextYAlignment = Enum.TextYAlignment.Top
    local metrics = { jumps = 0, landings = 0, distance = 0, maxDrop = 0, maxSpeed = 0, activeTime = 0 }
    local lastRoot, lastPosition, lastGrounded, airborneTop
    local nearby = {}
    local trailRoot, trail, leftAttachment, rightAttachment

    local function clearTrail()
        if trail then trail:Destroy(); trail = nil end
        if leftAttachment then leftAttachment:Destroy(); leftAttachment = nil end
        if rightAttachment then rightAttachment:Destroy(); rightAttachment = nil end
        trailRoot = nil
    end

    local function refreshTrail()
        local root = rootReady()
        if not root then clearTrail(); return end
        if trailRoot ~= root then
            clearTrail()
            leftAttachment = new("Attachment", { Name = "NebulaTrailLeft", Position = Vector3.new(-0.4, 0, 0) }, root)
            rightAttachment = new("Attachment", { Name = "NebulaTrailRight", Position = Vector3.new(0.4, 0, 0) }, root)
            trail = new("Trail", {
                Name = "NebulaMotionTrail", Attachment0 = leftAttachment, Attachment1 = rightAttachment,
                Lifetime = values.trailLifetime, MinLength = 0.1,
                Color = ColorSequence.new(palette.Cyan, palette.Rose),
            }, root)
            trailRoot = root
        end
        trail.Lifetime = values.trailLifetime
    end
    ctx.define("motionTrail", refreshTrail, clearTrail)

    local function scanNearby()
        table.clear(nearby)
        local root = rootReady()
        if not root then nearbyCaption.Text = "Karakter belum siap."; return end
        for _, other in ipairs(ctx.Players:GetPlayers()) do
            local friendly = ctx.player.Team ~= nil and other.Team == ctx.player.Team
            if other ~= ctx.player and not (values.scoutHideTeam and friendly) then
                local model = other.Character
                local target = model and model:FindFirstChild("HumanoidRootPart")
                if target then
                    local distance = (target.Position - root.Position).Magnitude
                    if distance <= values.scoutRange then
                        table.insert(nearby, { player = other, distance = distance })
                    end
                end
            end
        end
        table.sort(nearby, function(a, b)
            if a.distance == b.distance then return a.player.Name < b.player.Name end
            return a.distance < b.distance
        end)
        local lines = {}
        for index = 1, math.min(#nearby, values.scoutLimit) do
            local entry = nearby[index]
            lines[index] = string.format("@%s  ·  %.0f studs", entry.player.Name, entry.distance)
        end
        nearbyCaption.Text = #lines > 0 and table.concat(lines, "\n") or "Tidak ada pemain dalam jangkauan."
        scoutPanel.Size = UDim2.fromOffset(256, math.max(100, 40 + #lines * 18))
    end
    ctx.define("nearbyList", function()
        scoutPanel.Visible = true
        scanNearby()
    end, function()
        scoutPanel.Visible = false
        table.clear(nearby)
    end)
    ctx.define("motionMetrics", function()
        motionPanel.Visible = true
        lastPosition, lastGrounded, airborneTop = nil, nil, nil
    end, function()
        motionPanel.Visible = false
        lastPosition, lastGrounded, airborneTop = nil, nil, nil
    end)

    local scoutPage = page("Scout")
    toggle(scoutPage, "Nearby players panel", "nearbyList")
    toggle(scoutPage, "Hide same-team entries", "scoutHideTeam")
    slider(scoutPage, "Nearby range", "scoutRange")
    slider(scoutPage, "Maximum nearby entries", "scoutLimit")
    toggle(scoutPage, "Motion / jump / fall metrics", "motionMetrics")
    toggle(scoutPage, "Local motion trail", "motionTrail")
    slider(scoutPage, "Trail lifetime", "trailLifetime", function() ctx.refreshFeature("motionTrail") end)
    action(scoutPage, "Copy nearby player distances", function()
        scanNearby()
        local lines = {}
        for index = 1, math.min(#nearby, values.scoutLimit) do
            local entry = nearby[index]
            lines[index] = string.format("@%s: %.1f studs", entry.player.Name, entry.distance)
        end
        ctx.copyText(#lines > 0 and table.concat(lines, "\n") or "Tidak ada pemain dalam jangkauan.")
    end)
    action(scoutPage, "Measure selected player distance", function()
        local root = rootReady()
        local selected = ctx.getSelectedPlayer()
        local target = selected and selected.Character and selected.Character:FindFirstChild("HumanoidRootPart")
        assert(root and target, "Pilih pemain aktif di tab Players")
        ctx.notify(string.format("@%s: %.1f studs", selected.Name, (root.Position - target.Position).Magnitude))
    end)
    action(scoutPage, "Reset motion metrics", function()
        for key in pairs(metrics) do metrics[key] = 0 end
        lastPosition, lastGrounded, airborneTop = nil, nil, nil
        ctx.notify("Statistik gerakan direset.")
    end)
    note(scoutPage, "Daftar diperbarui setiap satu detik dari karakter yang sudah tersedia pada client. Streaming dapat menyembunyikan karakter jauh. Teleport besar tidak dihitung sebagai jarak berjalan.")

    local bloom, depth
    local function customBloom()
        if values.noBloom then ctx.setFeature("noBloom", false) end
        if not bloom then bloom = new("BloomEffect", { Name = "NebulaCustomBloom" }, ctx.Lighting) end
        bloom.Intensity, bloom.Size, bloom.Threshold = values.sceneBloomIntensity, values.sceneBloomSize, values.sceneBloomThreshold
    end
    local function clearBloom()
        if bloom then bloom:Destroy(); bloom = nil end
    end
    local function customDepth()
        if values.noBlur then ctx.setFeature("noBlur", false) end
        if not depth then depth = new("DepthOfFieldEffect", { Name = "NebulaCustomDepth" }, ctx.Lighting) end
        depth.FocusDistance, depth.InFocusRadius = values.sceneFocusDistance, values.sceneFocusRadius
        depth.NearIntensity, depth.FarIntensity = values.sceneNearIntensity, values.sceneFarIntensity
    end
    local function clearDepth()
        if depth then depth:Destroy(); depth = nil end
    end
    ctx.define("sceneBrightness", function()
        ctx.put("sceneBrightness", ctx.Lighting, "Brightness", values.sceneBrightnessValue, 30)
    end)
    ctx.define("sceneFog", function()
        ctx.put("sceneFog", ctx.Lighting, "FogStart", math.min(values.sceneFogStart, values.sceneFogEnd - 1), 30)
        ctx.put("sceneFog", ctx.Lighting, "FogEnd", values.sceneFogEnd, 30)
        ctx.put("sceneFog", ctx.Lighting, "FogColor", sceneColor(), 30)
    end)
    ctx.define("sceneAmbient", function()
        ctx.put("sceneAmbient", ctx.Lighting, "Ambient", sceneColor(), 30)
        ctx.put("sceneAmbient", ctx.Lighting, "OutdoorAmbient", sceneColor(), 30)
    end)
    ctx.define("sceneBloom", customBloom, clearBloom)
    ctx.define("sceneDepth", customDepth, clearDepth)

    local previousNoBloom = ctx.features.noBloom and ctx.features.noBloom.enable
    local previousNoBlur = ctx.features.noBlur and ctx.features.noBlur.enable
    local noBloomWrapper = function()
        if values.sceneBloom then ctx.setFeature("sceneBloom", false) end
        if previousNoBloom then previousNoBloom() end
    end
    local noBlurWrapper = function()
        if values.sceneDepth then ctx.setFeature("sceneDepth", false) end
        if previousNoBlur then previousNoBlur() end
    end
    if previousNoBloom then ctx.features.noBloom.enable = noBloomWrapper end
    if previousNoBlur then ctx.features.noBlur.enable = noBlurWrapper end

    local matte = new("Frame", {
        Name = "NebulaLetterbox", Size = UDim2.fromScale(1, 1),
        BackgroundTransparency = 1, Visible = false, ZIndex = 0,
    }, ctx.gui)
    local topBar = new("Frame", {
        Position = UDim2.fromScale(0, 0), Size = UDim2.fromScale(1, values.letterboxRatio),
        BackgroundColor3 = Color3.new(0, 0, 0), BorderSizePixel = 0, ZIndex = 0,
    }, matte)
    local bottomBar = new("Frame", {
        AnchorPoint = Vector2.new(0, 1), Position = UDim2.fromScale(0, 1),
        Size = UDim2.fromScale(1, values.letterboxRatio), BackgroundColor3 = Color3.new(0, 0, 0),
        BorderSizePixel = 0, ZIndex = 0,
    }, matte)
    ctx.define("letterbox", function()
        matte.Visible = true
    end, function()
        matte.Visible = false
    end)

    local scenePage = page("Scene")
    toggle(scenePage, "Override scene brightness", "sceneBrightness")
    slider(scenePage, "Scene brightness", "sceneBrightnessValue", function() ctx.refreshFeature("sceneBrightness") end)
    toggle(scenePage, "Custom distance fog", "sceneFog")
    slider(scenePage, "Fog start", "sceneFogStart", function() ctx.refreshFeature("sceneFog") end)
    slider(scenePage, "Fog end", "sceneFogEnd", function() ctx.refreshFeature("sceneFog") end)
    toggle(scenePage, "Custom ambient color", "sceneAmbient")
    local function refreshSceneColor()
        ctx.refreshFeature("sceneFog")
        ctx.refreshFeature("sceneAmbient")
    end
    slider(scenePage, "Scene red", "sceneRed", refreshSceneColor)
    slider(scenePage, "Scene green", "sceneGreen", refreshSceneColor)
    slider(scenePage, "Scene blue", "sceneBlue", refreshSceneColor)
    toggle(scenePage, "Custom bloom", "sceneBloom")
    slider(scenePage, "Bloom intensity", "sceneBloomIntensity", function() ctx.refreshFeature("sceneBloom") end)
    slider(scenePage, "Bloom size", "sceneBloomSize", function() ctx.refreshFeature("sceneBloom") end)
    slider(scenePage, "Bloom threshold", "sceneBloomThreshold", function() ctx.refreshFeature("sceneBloom") end)
    toggle(scenePage, "Custom depth of field", "sceneDepth")
    slider(scenePage, "Focus distance", "sceneFocusDistance", function() ctx.refreshFeature("sceneDepth") end)
    slider(scenePage, "Focus radius", "sceneFocusRadius", function() ctx.refreshFeature("sceneDepth") end)
    slider(scenePage, "Near blur intensity", "sceneNearIntensity", function() ctx.refreshFeature("sceneDepth") end)
    slider(scenePage, "Far blur intensity", "sceneFarIntensity", function() ctx.refreshFeature("sceneDepth") end)
    toggle(scenePage, "Cinematic letterbox", "letterbox")
    slider(scenePage, "Letterbox height", "letterboxRatio")
    action(scenePage, "Reset scene features", function()
        for _, key in ipairs({ "sceneBrightness", "sceneFog", "sceneAmbient", "sceneBloom", "sceneDepth" }) do ctx.setFeature(key, false) end
        values.letterbox = false
        ctx.sync("letterbox")
        ctx.notify("Fitur Scene dimatikan dan properti dipulihkan.")
    end)
    note(scenePage, "Scene adalah efek lokal. Custom bloom dan Disable bloom saling menonaktifkan; custom depth dan Disable blur juga saling eksklusif. Fog dan ambient Scene memiliki prioritas di atas Fullbright.")

    local rayParameters = RaycastParams.new()
    rayParameters.FilterType = Enum.RaycastFilterType.Exclude
    local fastElapsed, slowElapsed = 0, 0
    listen(ctx.Run.RenderStepped, function(dt)
        if cleaned or not ctx.isAlive() then return end
        local root, humanoid = rootReady()
        overlay.Visible, scoutPanel.Visible, motionPanel.Visible = values.reticle, values.nearbyList, values.motionMetrics
        matte.Visible = values.letterbox
        topBar.Size, bottomBar.Size = UDim2.fromScale(1, values.letterboxRatio), UDim2.fromScale(1, values.letterboxRatio)
        if values.reticle then
            local color = palette[values.reticleColor] or palette.White
            local length, thickness, gap = values.reticleSize, values.reticleThickness, values.reticleGap
            if values.reticleDynamic and root then gap = gap + math.min(root.AssemblyLinearVelocity.Magnitude * 0.12, 18) end
            local offset = gap + length / 2
            local positions = { { -offset, 0 }, { offset, 0 }, { 0, -offset }, { 0, offset } }
            for index, bar in ipairs(bars) do
                bar.Position = UDim2.new(0.5, positions[index][1], 0.5, positions[index][2])
                bar.Size = index <= 2 and UDim2.fromOffset(length, thickness) or UDim2.fromOffset(thickness, length)
                bar.BackgroundColor3, bar.BackgroundTransparency = color, 1 - values.reticleOpacity
            end
            dot.Visible, ring.Visible = values.reticleDot, values.reticleRing
            dot.Size = UDim2.fromOffset(thickness + 1, thickness + 1)
            dot.BackgroundColor3, dot.BackgroundTransparency = color, 1 - values.reticleOpacity
            ring.Size = UDim2.fromOffset((gap + length) * 2, (gap + length) * 2)
            ringStroke.Color, ringStroke.Transparency, ringStroke.Thickness = color, 1 - values.reticleOpacity, thickness
            targetCaption.Visible = values.reticleTargetInfo
            targetCaption.TextColor3 = color
        end
        if values.motionMetrics and root then
            metrics.activeTime = metrics.activeTime + dt
            metrics.maxSpeed = math.max(metrics.maxSpeed, root.AssemblyLinearVelocity.Magnitude)
            if root ~= lastRoot then lastRoot, lastPosition, lastGrounded, airborneTop = root, nil, nil, nil end
            if lastPosition then
                local traveled = (root.Position - lastPosition).Magnitude
                if traveled < 100 then metrics.distance = metrics.distance + traveled end
            end
            local grounded = humanoid.FloorMaterial ~= Enum.Material.Air
            if lastGrounded == true and not grounded and root.AssemblyLinearVelocity.Y > 1 then metrics.jumps = metrics.jumps + 1 end
            if not grounded then airborneTop = math.max(airborneTop or root.Position.Y, root.Position.Y) end
            if lastGrounded == false and grounded then
                metrics.landings = metrics.landings + 1
                metrics.maxDrop = math.max(metrics.maxDrop, (airborneTop or root.Position.Y) - root.Position.Y)
                airborneTop = nil
            end
            lastPosition, lastGrounded = root.Position, grounded
        elseif not values.motionMetrics then lastPosition, lastGrounded, airborneTop = nil, nil, nil end
        fastElapsed, slowElapsed = fastElapsed + dt, slowElapsed + dt
        if fastElapsed >= 0.2 then
            fastElapsed = 0
            if values.motionTrail then refreshTrail() end
            if values.motionMetrics then
                motionCaption.Text = string.format("MOTION  |  %.0fs\nJump %d / land %d  |  %.0f studs\nPeak %.1f studs/s  |  Drop %.1f\nVertical speed %.1f", metrics.activeTime,
                    metrics.jumps, metrics.landings, metrics.distance, metrics.maxSpeed, metrics.maxDrop, root and root.AssemblyLinearVelocity.Y or 0)
            end
            if values.reticle and values.reticleTargetInfo then
                local camera = ctx.workspace.CurrentCamera
                if camera then
                    local filter = { ctx.effectFolder }
                    local character = ctx.getCharacter()
                    if character then table.insert(filter, character) end
                    rayParameters.FilterDescendantsInstances = filter
                    local hit = ctx.workspace:Raycast(camera.CFrame.Position, camera.CFrame.LookVector * values.reticleRayDistance, rayParameters)
                    targetCaption.Text = hit and string.format("%s  |  %.1f studs", hit.Instance.Name, hit.Distance) or "Tidak ada permukaan dalam jangkauan"
                else targetCaption.Text = "Kamera belum siap" end
            end
        end
        if slowElapsed >= 1 then
            slowElapsed = 0
            if values.nearbyList then scanNearby() end
        end
    end)

    return function()
        if cleaned then return end
        cleaned = true
        for _, connection in ipairs(ownedConnections) do connection:Disconnect() end
        table.clear(ownedConnections)
        clearTrail()
        clearBloom()
        clearDepth()
        for _, owner in ipairs({ "sceneBrightness", "sceneFog", "sceneAmbient" }) do ctx.release(owner) end
        if previousNoBloom and ctx.features.noBloom.enable == noBloomWrapper then ctx.features.noBloom.enable = previousNoBloom end
        if previousNoBlur and ctx.features.noBlur.enable == noBlurWrapper then ctx.features.noBlur.enable = previousNoBlur end
        overlay:Destroy()
        scoutPanel:Destroy()
        motionPanel:Destroy()
        matte:Destroy()
    end
end
