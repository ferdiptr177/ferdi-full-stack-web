-- Upgrade module: runs in the same lexical scope as the base panel.
local Pathfinding = game:GetService("PathfindingService")
local startedAt = os.clock()
local totalFrames, totalSeconds, traveled, maxSpeed = 0, 0, 0, 0
local lastMeasuredPosition, lastSafePosition
local routeGeneration, activeRoute = 0, false
local routeControls
local cameraMode, gradeEffect, airPlatform
local recordedPath, playingPath = {}, nil
local recordStarted, recordElapsed = nil, 0
local selectedPreset = 1
local cameraSavedViews = {}
local internalChanges = false
local library = NEBULA_PRESETS

local function positionOf(model)
    return model and model:FindFirstChild("HumanoidRootPart")
end

local function stopRoute()
    routeGeneration = routeGeneration + 1
    activeRoute = false
    if humanoid and root then humanoid:MoveTo(root.Position) end
    if routeControls then
        if routeControls.wasEnabled then pcall(function() routeControls.controls:Enable() end) end
        routeControls = nil
    end
end

local function finishRoute(ticket)
    if ticket ~= routeGeneration then return end
    activeRoute = false
    if routeControls and routeControls.ticket == ticket then
        local owned = routeControls
        routeControls = nil
        if owned.wasEnabled then pcall(function() owned.controls:Enable() end) end
    end
end

local function beginRoute(destination)
    assert(liveRoot(), "Karakter belum siap")
    assert(not values.fly and not values.freezeSelf, "Matikan flight/freeze sebelum navigasi")
    stopRoute()
    local ticket, movingHumanoid, movingRoot = routeGeneration, humanoid, root
    local scripts = player:FindFirstChild("PlayerScripts")
    local module = scripts and scripts:FindFirstChild("PlayerModule")
    assert(module and module:IsA("ModuleScript"), "Kontrol PlayerModule tidak tersedia; navigasi dibatalkan")
    local okControls, controls = pcall(function() return require(module):GetControls() end)
    assert(okControls and type(controls) == "table" and type(controls.controlsEnabled) == "boolean"
        and type(controls.Disable) == "function" and type(controls.Enable) == "function",
        "Kontrol default tidak dikenali; navigasi dibatalkan")
    routeControls = { controls = controls, wasEnabled = controls.controlsEnabled, ticket = ticket }
    if routeControls.wasEnabled then
        local disabled, failure = pcall(function() controls:Disable() end)
        if not disabled then finishRoute(ticket); error(tostring(failure)) end
    end
    activeRoute = true
    notify("Menghitung jalur menuju bookmark...")
    task.spawn(function()
        local created, path = pcall(function() return Pathfinding:CreatePath({
            AgentRadius = 2,
            AgentHeight = 5,
            AgentCanJump = true,
            WaypointSpacing = 4,
        }) end)
        if not created then finishRoute(ticket); notify("Pathfinding gagal: " .. tostring(path)); return end
        local ok, err = pcall(function() path:ComputeAsync(movingRoot.Position, destination) end)
        if not alive or ticket ~= routeGeneration then path:Destroy(); return end
        if not ok or path.Status ~= Enum.PathStatus.Success then
            finishRoute(ticket)
            path:Destroy()
            notify("Jalur tidak ditemukan: " .. tostring(err or "area terhalang"))
            return
        end
        local blocked = false
        local currentWaypoint = 1
        local blockedConnection = path.Blocked:Connect(function(index)
            if index >= currentWaypoint then blocked = true end
        end)
        local success, failure = pcall(function()
            for index, waypoint in ipairs(path:GetWaypoints()) do
                currentWaypoint = index
                if not alive or ticket ~= routeGeneration or blocked or movingHumanoid.Health <= 0 then break end
                if waypoint.Action == Enum.PathWaypointAction.Jump then movingHumanoid.Jump = true end
                movingHumanoid:MoveTo(waypoint.Position)
                local timeout = os.clock() + 8
                repeat
                    task.wait(0.05)
                until not alive or ticket ~= routeGeneration or blocked
                    or movingHumanoid.Health <= 0 or not movingRoot.Parent
                    or (movingRoot.Position - waypoint.Position).Magnitude <= 4
                    or os.clock() >= timeout
                if not movingRoot.Parent or os.clock() >= timeout then
                    error("Waypoint tidak tercapai sebelum batas waktu")
                end
            end
        end)
        blockedConnection:Disconnect()
        path:Destroy()
        if not alive or ticket ~= routeGeneration then return end
        finishRoute(ticket)
        if blocked then notify("Jalur berubah/terhalang. Jalankan navigasi lagi.")
        elseif not success then notify("Navigasi berhenti: " .. tostring(failure))
        elseif movingHumanoid.Health <= 0 then notify("Navigasi berhenti: karakter mati.")
        else notify("Navigasi selesai.") end
    end)
end

local rayParameters = RaycastParams.new()
rayParameters.FilterType = Enum.RaycastFilterType.Exclude
local function castFrom(origin, direction)
    local excluded = { effectFolder }
    if character then table.insert(excluded, character) end
    rayParameters.FilterDescendantsInstances = excluded
    return workspace:Raycast(origin, direction, rayParameters)
end

define("freezeSelf", function()
    stopRoute()
    assert(not values.fly, "Matikan flight terlebih dahulu")
    if root then put("freezeSelf", root, "Anchored", true) end
end)
define("bunnyHop", function() end)
define("airWalk", function()
    if airPlatform then return end
    airPlatform = new("Part", {
        Name = "NebulaAirPlatform", Size = Vector3.new(8, 0.4, 8),
        Anchored = true, CanCollide = true, CanTouch = false,
        CanQuery = false, Transparency = 1, CFrame = CFrame.new(0, -100000, 0),
    }, effectFolder)
end, function()
    if airPlatform then airPlatform:Destroy(); airPlatform = nil end
end)
define("voidReturn", function() end)
define("noAutoRotate", function()
    if humanoid then put("noAutoRotate", humanoid, "AutoRotate", false, 20) end
end)
define("alwaysSit", function()
    if humanoid then put("alwaysSit", humanoid, "Sit", true) end
end)

local function clearAtmosphere()
    for _, object in ipairs(Lighting:GetChildren()) do
        if object:IsA("Atmosphere") then
            put("clearAtmosphere", object, "Density", 0)
            put("clearAtmosphere", object, "Haze", 0)
            put("clearAtmosphere", object, "Glare", 0)
        end
    end
end
define("clearAtmosphere", clearAtmosphere)
define("exposure", function() put("exposure", Lighting, "ExposureCompensation", values.exposureValue) end)
define("noBloom", function()
    local containers = { Lighting }
    if workspace.CurrentCamera then table.insert(containers, workspace.CurrentCamera) end
    for _, container in ipairs(containers) do
        for _, effect in ipairs(container:GetChildren()) do
            if effect:IsA("BloomEffect") or effect:IsA("SunRaysEffect") then put("noBloom", effect, "Enabled", false) end
        end
    end
end)
define("noShadows", function() put("noShadows", Lighting, "GlobalShadows", false, 20) end)

local gradeDefinitions = {
    Neutral = { 0, 0, 0, Color3.new(1, 1, 1) },
    Filmic = { 0, 0.18, -0.12, Color3.fromRGB(255, 238, 220) },
    Mono = { 0, 0.12, -1, Color3.new(1, 1, 1) },
    Warm = { 0.03, 0.04, 0.05, Color3.fromRGB(255, 225, 195) },
    Cool = { 0.02, 0.07, -0.05, Color3.fromRGB(205, 230, 255) },
    Soft = { 0.04, -0.12, -0.1, Color3.fromRGB(250, 235, 255) },
}
local function applyGrade()
    local grade = gradeDefinitions[values.colorGrade] or gradeDefinitions.Neutral
    if not gradeEffect then gradeEffect = new("ColorCorrectionEffect", { Name = "NebulaColorGrade" }, Lighting) end
    gradeEffect.Brightness, gradeEffect.Contrast, gradeEffect.Saturation, gradeEffect.TintColor = table.unpack(grade)
end
define("grade", applyGrade, function()
    if gradeEffect then gradeEffect:Destroy(); gradeEffect = nil end
end)

local function stopCamera()
    cameraMode = nil
    playingPath = nil
    release("freecam")
    release("orbit")
    release("pathPlayback")
    release("freecamPointer")
    local camera = workspace.CurrentCamera
    if camera and humanoid and (not camera.CameraSubject or not camera.CameraSubject.Parent) then
        camera.CameraSubject = humanoid
    end
end

local function stopCameraMode(owner)
    if cameraMode and cameraMode.mode == owner then stopCamera()
    else release(owner) end
end

local function cameraConflict(except)
    internalChanges = true
    for _, key in ipairs({ "freecam", "orbit", "pathPlayback", "spectate" }) do
        if key ~= except and values[key] then setFeature(key, false) end
    end
    internalChanges = false
end

define("freecam", function()
    cameraConflict("freecam")
    local camera = workspace.CurrentCamera
    assert(camera, "Kamera belum siap")
    local x, y = camera.CFrame:ToOrientation()
    cameraMode = { mode = "freecam", frame = camera.CFrame, pitch = x, yaw = y }
    put("freecam", camera, "CameraType", Enum.CameraType.Scriptable, 30)
    put("freecam", camera, "CFrame", camera.CFrame, 30)
end, function() stopCameraMode("freecam") end)
define("orbit", function()
    assert(selectedPlayer and selectedPlayer.Parent == Players, "Pilih pemain pada tab Players")
    cameraConflict("orbit")
    cameraMode = { mode = "orbit", angle = 0 }
    put("orbit", workspace.CurrentCamera, "CameraType", Enum.CameraType.Scriptable, 30)
    put("orbit", workspace.CurrentCamera, "CFrame", workspace.CurrentCamera.CFrame, 30)
end, function() stopCameraMode("orbit") end)
define("pathPlayback", function()
    assert(#recordedPath >= 2, "Rekam minimal dua frame kamera terlebih dahulu")
    recordStarted = nil
    cameraConflict("pathPlayback")
    playingPath = { started = os.clock(), index = 1 }
    cameraMode = { mode = "pathPlayback" }
    put("pathPlayback", workspace.CurrentCamera, "CameraType", Enum.CameraType.Scriptable, 30)
    put("pathPlayback", workspace.CurrentCamera, "CFrame", workspace.CurrentCamera.CFrame, 30)
end, function() stopCameraMode("pathPlayback") end)

local cameraPage = page("Camera")
toggle(cameraPage, "Free camera", "freecam")
slider(cameraPage, "Free camera speed", "freecamSpeed")
slider(cameraPage, "Mouse sensitivity", "cameraSensitivity")
note(cameraPage, "Freecam: WASD, Q/E turun/naik. Tahan klik kanan untuk melihat. Mobile memakai thumbstick serta UP/DOWN; karakter tetap berada di dunia.")
toggle(cameraPage, "Orbit selected player", "orbit")
slider(cameraPage, "Orbit radius", "orbitRadius")
slider(cameraPage, "Orbit height", "orbitHeight")
slider(cameraPage, "Orbit speed", "orbitSpeed")
action(cameraPage, "Start camera recording", function()
    setFeature("pathPlayback", false)
    recordedPath = {}
    recordStarted, recordElapsed = os.clock(), 0
    notify("Merekam kamera maksimal 60 detik. Gunakan Stop untuk menyelesaikan.")
end)
action(cameraPage, "Stop camera recording", function()
    recordStarted = nil
    notify("Rekaman kamera: " .. #recordedPath .. " frame.")
end)
toggle(cameraPage, "Play camera recording", "pathPlayback")
toggle(cameraPage, "Loop camera recording", "loopCamera")
for slot = 1, 3 do
    action(cameraPage, "Save camera view " .. slot, function()
        assert(workspace.CurrentCamera, "Kamera belum siap")
        cameraSavedViews[slot] = workspace.CurrentCamera.CFrame
        notify("View kamera " .. slot .. " disimpan.")
    end)
    action(cameraPage, "Restore camera view " .. slot, function()
        assert(cameraSavedViews[slot], "View ini belum disimpan")
        if not values.freecam then setFeature("freecam", true) end
        assert(cameraMode and cameraMode.mode == "freecam", "Freecam tidak aktif")
        local frame = cameraSavedViews[slot]
        local x, y = frame:ToOrientation()
        cameraMode.frame, cameraMode.pitch, cameraMode.yaw = frame, x, y
    end)
end
action(cameraPage, "Return to normal camera", function()
    for _, key in ipairs({ "freecam", "orbit", "pathPlayback", "spectate" }) do setFeature(key, false) end
    stopCamera()
end)

local navigatePage = page("Navigate")
for slot = 1, 3 do
    action(navigatePage, "Walk path to bookmark " .. slot, function()
        assert(savedPlaces[slot], "Simpan bookmark pada tab Places terlebih dahulu")
        beginRoute(savedPlaces[slot].Position)
    end)
end
action(navigatePage, "Cancel navigation", function() stopRoute(); notify("Navigasi dibatalkan.") end)
action(navigatePage, "Teleport to camera raycast", function()
    local camera = workspace.CurrentCamera
    assert(camera, "Kamera belum siap")
    local hit = castFrom(camera.CFrame.Position, camera.CFrame.LookVector * values.rayDistance)
    assert(hit, "Tidak ada permukaan pada arah kamera")
    goTo(CFrame.new(hit.Position + hit.Normal * 3 + Vector3.yAxis * 3))
end)
slider(navigatePage, "Raycast distance", "rayDistance")
toggle(navigatePage, "Show bookmark markers", "bookmarkMarkers")
toggle(navigatePage, "Direction arrow to bookmark 1", "directionArrow")
toggle(navigatePage, "Return from void to last safe ground", "voidReturn")
slider(navigatePage, "Void Y threshold", "voidY")
note(navigatePage, "Navigasi memakai PathfindingService. Medan streaming, platform bergerak, pintu, dan aturan server dapat menghalangi jalur.")

toggle(movePage, "Freeze own root locally", "freezeSelf")
toggle(movePage, "Automatic bunny hop", "bunnyHop")
toggle(movePage, "Local air-walk platform", "airWalk")
toggle(movePage, "Disable auto rotate", "noAutoRotate")
toggle(movePage, "Sit", "alwaysSit")
slider(movePage, "Dash impulse speed", "dashSpeed")
action(movePage, "Dash forward", function()
    assert(liveRoot() and not values.freezeSelf, "Karakter belum siap atau sedang freeze")
    local forward = root.CFrame.LookVector
    local flat = Vector3.new(forward.X, 0, forward.Z)
    if flat.Magnitude > 0 then root.AssemblyLinearVelocity = flat.Unit * values.dashSpeed + Vector3.yAxis * root.AssemblyLinearVelocity.Y end
end)

toggle(visualPage, "Clear Atmosphere density / haze", "clearAtmosphere")
toggle(visualPage, "Disable bloom / sun rays", "noBloom")
toggle(visualPage, "Disable global shadows", "noShadows")
toggle(visualPage, "Custom exposure", "exposure")
slider(visualPage, "Exposure compensation", "exposureValue", function() refreshFeature("exposure") end)
toggle(visualPage, "Color grade", "grade")
for _, name in ipairs({ "Neutral", "Filmic", "Mono", "Warm", "Cool", "Soft" }) do
    action(visualPage, "Color grade: " .. name, function()
        values.colorGrade = name
        refreshFeature("grade")
        notify("Color grade dipilih: " .. name)
    end)
end

local hud = new("Frame", {
    Name = "NebulaHUD", Position = UDim2.new(0, 16, 1, -160),
    Size = UDim2.fromOffset(270, 140), BackgroundColor3 = Color3.fromRGB(22, 20, 33),
    BackgroundTransparency = 0.15, Visible = false,
}, gui)
round(hud)
colored(new("UIStroke", { Transparency = 0.4 }, hud), "Color")
local compass = text(hud, "", UDim2.new(1, -20, 0, 24), UDim2.fromOffset(10, 6), 13)
local speedLabel = text(hud, "", UDim2.new(1, -20, 0, 24), UDim2.fromOffset(10, 32), 12)
local sessionLabel = text(hud, "", UDim2.new(1, -20, 0, 24), UDim2.fromOffset(10, 58), 11)
local healthBackground = new("Frame", {
    Position = UDim2.fromOffset(10, 92), Size = UDim2.new(1, -20, 0, 9),
    BackgroundColor3 = Color3.fromRGB(60, 48, 65), BorderSizePixel = 0,
}, hud)
round(healthBackground, 4)
local healthFill = colored(new("Frame", { Size = UDim2.fromScale(1, 1), BorderSizePixel = 0 }, healthBackground), "BackgroundColor3")
round(healthFill, 4)
local healthLabel = text(hud, "", UDim2.new(1, -20, 0, 20), UDim2.fromOffset(10, 108), 10)
local arrow = text(gui, "▲", UDim2.fromOffset(56, 56), UDim2.new(0.5, -28, 0.15, 0), 34)
arrow.TextXAlignment, arrow.Visible = Enum.TextXAlignment.Center, false
colored(arrow, "TextColor3")
define("floatingHUD", function() hud.Visible = true end, function() hud.Visible = false end)
define("directionArrow", function() end, function() arrow.Visible = false end)
define("rainbow", function() end, applyTheme)

local hudPage = page("HUD")
toggle(hudPage, "Floating HUD", "floatingHUD")
toggle(hudPage, "Compass", "compass")
toggle(hudPage, "Speedometer", "speedometer")
toggle(hudPage, "Health bar", "healthBar")
toggle(hudPage, "Session statistics", "sessionStats")
toggle(hudPage, "Rainbow accent", "rainbow")
slider(hudPage, "HUD opacity", "hudOpacity", function() hud.BackgroundTransparency = 1 - values.hudOpacity end)
action(hudPage, "Move HUD to left", function() hud.Position = UDim2.new(0, 16, 1, -160) end)
action(hudPage, "Move HUD to right", function() hud.Position = UDim2.new(1, -286, 1, -160) end)
action(hudPage, "Reset session metrics", function()
    totalFrames, totalSeconds, traveled, maxSpeed = 0, 0, 0, 0
    startedAt, lastMeasuredPosition = os.clock(), nil
    notify("Statistik sesi direset.")
end)

local timerEnd, timerRunning = nil, false
local toolsPage = page("Tools")
slider(toolsPage, "Countdown seconds", "timerSeconds")
action(toolsPage, "Start countdown", function()
    timerEnd, timerRunning = os.clock() + values.timerSeconds, true
    notify("Timer dimulai: " .. values.timerSeconds .. " detik.")
end)
action(toolsPage, "Cancel countdown", function() timerRunning = false; notify("Timer dibatalkan.") end)
action(toolsPage, "Inspect selected player", function()
    assert(selectedPlayer, "Pilih pemain pada tab Players")
    local model = selectedPlayer.Character
    local targetHumanoid = model and model:FindFirstChildOfClass("Humanoid")
    copyText(string.format("@%s | UserId %s | Team %s | HP %s", selectedPlayer.Name,
        tostring(selectedPlayer.UserId), selectedPlayer.Team and selectedPlayer.Team.Name or "none",
        targetHumanoid and tostring(targetHumanoid.Health) or "no character"))
end)
action(toolsPage, "Copy session diagnostics", function()
    local count = 0
    for key in pairs(features) do if values[key] then count = count + 1 end end
    copyText(string.format("NEBULA 15000 | Place %s | Players %d | Features %d | Uptime %ds | Travel %.0f studs",
        tostring(game.PlaceId), #Players:GetPlayers(), count, math.floor(os.clock() - startedAt), traveled))
end)
action(toolsPage, "Stop all movement automation", function()
    stopRoute()
    for _, key in ipairs({ "fly", "airWalk", "bunnyHop", "freezeSelf", "alwaysSit" }) do setFeature(key, false) end
    notify("Otomasi gerakan dihentikan.")
end)
action(toolsPage, "Stop all features", function()
    stopRoute()
    recordStarted = nil
    for key in pairs(features) do setFeature(key, false) end
    notify("Semua toggle fitur dimatikan.")
end)
local diagnosticLabel = note(toolsPage, "Diagnostik runtime akan muncul di sini.")
note(toolsPage, "API clipboard/file bersifat opsional. Preset dan profil tidak menjalankan kode yang diunduh, tidak mengirim data ke endpoint eksternal.")

local libraryPage = page("Library")
local presetTitle = note(libraryPage, "")
local presetDetail = note(libraryPage, "")
local function previewPreset()
    local preset = library[selectedPreset]
    presetTitle.Text = string.format("%d / %d | %s", selectedPreset, #library, preset.name)
    presetDetail.Text = preset.description
end
action(libraryPage, "Previous preset", function() selectedPreset = (selectedPreset - 2) % #library + 1; previewPreset() end)
action(libraryPage, "Next preset", function() selectedPreset = selectedPreset % #library + 1; previewPreset() end)
action(libraryPage, "Next 10 presets", function() selectedPreset = (selectedPreset + 9) % #library + 1; previewPreset() end)
action(libraryPage, "Apply selected preset", function()
    applyProfile(library[selectedPreset].values)
    notify("Preset diterapkan: " .. library[selectedPreset].name)
end)
action(libraryPage, "Copy selected preset JSON", function() copyText(Http:JSONEncode(library[selectedPreset].values)) end)
note(libraryPage, "Preset adalah snapshot pengaturan lengkap. Menerapkan preset akan menggantikan pengaturan aktif, termasuk mematikan fitur yang tidak digunakan preset.")
previewPreset()

local markers = {}
local function refreshMarkers()
    for index = 1, 3 do
        local frame = savedPlaces[index]
        if not values.bookmarkMarkers or not frame then
            if markers[index] then markers[index]:Destroy(); markers[index] = nil end
        else
            if not markers[index] then
                local marker = new("Part", {
                    Name = "NebulaBookmark" .. index, Size = Vector3.new(0.5, 0.5, 0.5),
                    Anchored = true, CanCollide = false, CanTouch = false,
                    CanQuery = false, Transparency = 1,
                }, effectFolder)
                local tag = new("BillboardGui", {
                    Adornee = marker, AlwaysOnTop = true, Size = UDim2.fromOffset(110, 30),
                    StudsOffsetWorldSpace = Vector3.new(0, 3, 0),
                }, marker)
                local caption = text(tag, "BOOKMARK " .. index, UDim2.fromScale(1, 1), nil, 12)
                caption.TextXAlignment = Enum.TextXAlignment.Center
                caption.TextColor3 = accent
                markers[index] = marker
            end
            markers[index].CFrame = frame
        end
    end
end
define("bookmarkMarkers", refreshMarkers, refreshMarkers)

local function freeCameraStep(dt)
    local camera = workspace.CurrentCamera
    if not cameraMode or not camera then return end
    if cameraMode.mode == "freecam" then
        local movement = Vector3.zero
        if focused and not Input:GetFocusedTextBox() then
            local x, y, z = 0, 0, 0
            if Input:IsKeyDown(Enum.KeyCode.D) then x = x + 1 end
            if Input:IsKeyDown(Enum.KeyCode.A) then x = x - 1 end
            if Input:IsKeyDown(Enum.KeyCode.E) or upHeld then y = y + 1 end
            if Input:IsKeyDown(Enum.KeyCode.Q) or downHeld then y = y - 1 end
            if Input:IsKeyDown(Enum.KeyCode.W) then z = z - 1 end
            if Input:IsKeyDown(Enum.KeyCode.S) then z = z + 1 end
            if Input:IsMouseButtonPressed(Enum.UserInputType.MouseButton2) then
                put("freecamPointer", Input, "MouseBehavior", Enum.MouseBehavior.LockCurrentPosition)
                local delta = Input:GetMouseDelta()
                cameraMode.yaw = cameraMode.yaw - delta.X * values.cameraSensitivity * 0.002
                cameraMode.pitch = math.clamp(cameraMode.pitch - delta.Y * values.cameraSensitivity * 0.002, -1.5, 1.5)
            else release("freecamPointer") end
            local rotation = CFrame.fromOrientation(cameraMode.pitch, cameraMode.yaw, 0)
            movement = rotation:VectorToWorldSpace(Vector3.new(x, y, z))
            if Input.TouchEnabled and humanoid then movement = movement + humanoid.MoveDirection end
            if movement.Magnitude > 1 then movement = movement.Unit end
            cameraMode.frame = CFrame.new(cameraMode.frame.Position + movement * values.freecamSpeed * dt) * rotation
        end
        if not focused or Input:GetFocusedTextBox() then release("freecamPointer") end
        put("freecam", camera, "CFrame", cameraMode.frame, 30)
    elseif cameraMode.mode == "orbit" then
        local target = selectedPlayer and positionOf(selectedPlayer.Character)
        if not target then return end
        cameraMode.angle = cameraMode.angle + math.rad(values.orbitSpeed) * dt
        local offset = Vector3.new(math.cos(cameraMode.angle) * values.orbitRadius, values.orbitHeight, math.sin(cameraMode.angle) * values.orbitRadius)
        put("orbit", camera, "CFrame", CFrame.lookAt(target.Position + offset, target.Position), 30)
    elseif cameraMode.mode == "pathPlayback" and playingPath then
        if #recordedPath < 2 then setFeature("pathPlayback", false); return end
        local time = os.clock() - playingPath.started
        local last = recordedPath[#recordedPath]
        if time >= last.time then
            if values.loopCamera then playingPath.started, playingPath.index = os.clock(), 1; time = 0
            else setFeature("pathPlayback", false); return end
        end
        local index = playingPath.index
        while index < #recordedPath - 1 and recordedPath[index + 1].time < time do index = index + 1 end
        playingPath.index = index
        local first, second = recordedPath[index], recordedPath[index + 1]
        local alpha = math.clamp((time - first.time) / math.max(second.time - first.time, 0.001), 0, 1)
        put("pathPlayback", camera, "CFrame", first.frame:Lerp(second.frame, alpha), 30)
    end
end

local featureOwners = { "freezeSelf", "noAutoRotate", "alwaysSit" }
connect(player.CharacterRemoving, function()
    stopRoute()
    lastSafePosition, lastMeasuredPosition = nil, nil
    for _, owner in ipairs(featureOwners) do release(owner) end
end)
connect(player.CharacterAdded, function(model)
    task.spawn(function()
        local h = model:WaitForChild("Humanoid", 15)
        local r = model:WaitForChild("HumanoidRootPart", 15)
        if not alive or not h or not r or player.Character ~= model then return end
        local deadline = os.clock() + 20
        repeat task.wait() until not alive or player.Character ~= model or humanoid == h or os.clock() >= deadline
        if not alive or player.Character ~= model or humanoid ~= h then return end
        for _, owner in ipairs(featureOwners) do if values[owner] then pcall(features[owner].enable) end end
    end)
end)
connect(workspace:GetPropertyChangedSignal("CurrentCamera"), function()
    if cameraMode then
        local active = cameraMode.mode
        release(active)
        pcall(function() features[active].enable() end)
    end
end)
connect(Input.WindowFocusReleased, function() release("freecamPointer") end)

connect(Run.PreSimulation, function()
    if airPlatform and liveRoot() then
        local offset = humanoid.HipHeight + root.Size.Y / 2 + 0.3
        airPlatform.CFrame = CFrame.new(root.Position - Vector3.yAxis * offset)
    end
    if values.bunnyHop and liveRoot() and not values.fly and not values.freezeSelf and not humanoid.Sit
        and humanoid.MoveDirection.Magnitude > 0.1 and humanoid.FloorMaterial ~= Enum.Material.Air then
        humanoid.Jump = true
    end
end)

local sampleElapsed, paletteElapsed = 0, 0
connect(Run.RenderStepped, function(dt)
    totalFrames, totalSeconds = totalFrames + 1, totalSeconds + dt
    if cameraMode then freeCameraStep(dt) end
    flightPad.Visible = values.fly or values.freecam
    hud.Visible = values.floatingHUD
    if recordStarted and workspace.CurrentCamera then
        recordElapsed = recordElapsed + dt
        if recordElapsed >= 0.1 then
            recordElapsed = 0
            table.insert(recordedPath, { time = os.clock() - recordStarted, frame = workspace.CurrentCamera.CFrame })
            if os.clock() - recordStarted >= 60 then recordStarted = nil; notify("Rekaman kamera mencapai 60 detik.") end
        end
    end
    if liveRoot() then
        local speed = root.AssemblyLinearVelocity.Magnitude
        maxSpeed = math.max(maxSpeed, speed)
        if lastMeasuredPosition then
            local step = (root.Position - lastMeasuredPosition).Magnitude
            if step < 100 then traveled = traveled + step end
        end
        lastMeasuredPosition = root.Position
        if values.voidReturn and lastSafePosition and root.Position.Y < values.voidY then
            root.CFrame = lastSafePosition
            root.AssemblyLinearVelocity = Vector3.zero
        end
    end
    sampleElapsed, paletteElapsed = sampleElapsed + dt, paletteElapsed + dt
    if sampleElapsed < 0.25 then return end
    sampleElapsed = 0
    if liveRoot() then
        local ground = castFrom(root.Position, Vector3.new(0, -12, 0))
        if ground and humanoid.FloorMaterial ~= Enum.Material.Air then lastSafePosition = root.CFrame end
        local speed = root.AssemblyLinearVelocity.Magnitude
        speedLabel.Text = string.format("SPEED %.1f studs/s | MAX %.1f", speed, maxSpeed)
        healthFill.Size = UDim2.fromScale(math.clamp(humanoid.Health / math.max(humanoid.MaxHealth, 1), 0, 1), 1)
        healthLabel.Text = string.format("HP %.0f / %.0f", humanoid.Health, humanoid.MaxHealth)
    end
    local camera = workspace.CurrentCamera
    if camera then
        local look = camera.CFrame.LookVector
        local headingDegrees = (math.deg(math.atan2(look.X, -look.Z)) + 360) % 360
        local labels = { "N", "NE", "E", "SE", "S", "SW", "W", "NW" }
        compass.Text = string.format("%s  |  %.0f°", labels[math.floor((headingDegrees + 22.5) / 45) % 8 + 1], headingDegrees)
        arrow.Visible = values.directionArrow and savedPlaces[1] ~= nil and root ~= nil
        if arrow.Visible then
            local relative = camera.CFrame:VectorToObjectSpace(savedPlaces[1].Position - root.Position)
            arrow.Rotation = math.deg(math.atan2(relative.X, -relative.Z))
        end
    end
    compass.Visible, speedLabel.Visible = values.compass, values.speedometer
    healthBackground.Visible, healthLabel.Visible = values.healthBar, values.healthBar
    sessionLabel.Visible = values.sessionStats
    sessionLabel.Text = string.format("%ds | %.0f studs | AVG %.0f FPS", math.floor(os.clock() - startedAt), traveled, totalFrames / math.max(totalSeconds, 0.001))
    if timerRunning and os.clock() >= timerEnd then timerRunning = false; notify("Timer selesai.") end
    refreshMarkers()
    if values.clearAtmosphere then clearAtmosphere() end
    if values.noBloom then features.noBloom.enable() end
    if values.rainbow and paletteElapsed >= 0.5 then
        paletteElapsed = 0
        accent = Color3.fromHSV((os.clock() % 12) / 12, 0.65, 1)
        for _, binding in ipairs(accentBindings) do if binding[1].Parent then binding[1][binding[2]] = accent end end
    end
    diagnosticLabel.Text = string.format("Route: %s | Camera frames: %d | Presets: %d | Runtime: %ds",
        activeRoute and "ACTIVE" or "IDLE", #recordedPath, #library, math.floor(os.clock() - startedAt))
end)

local originalSetSpectate = features.spectate.enable
features.spectate.enable = function()
    if not internalChanges then cameraConflict("spectate") end
    originalSetSpectate()
end

local originalFlyEnable = features.fly.enable
features.fly.enable = function()
    assert(not values.freezeSelf, "Matikan freeze sebelum flight")
    stopRoute()
    originalFlyEnable()
end

connect(Players.PlayerRemoving, function()
    if values.orbit and not selectedPlayer then setFeature("orbit", false) end
end)

local upgradeCleanup = function()
    stopRoute()
    recordStarted, timerRunning = nil, false
    stopCamera()
    if gradeEffect then gradeEffect:Destroy(); gradeEffect = nil end
    if airPlatform then airPlatform:Destroy(); airPlatform = nil end
end
