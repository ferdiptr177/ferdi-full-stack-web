#!/usr/bin/env python3
"""Build the standalone panel and its complete, selectable profile catalog.

All generated records are independent, importable configuration snapshots.
The exact source length is achieved by wrapping catalog descriptions, not by
inserting empty lines, fake features, inert comments, or duplicated profiles.
"""

from pathlib import Path
import hashlib
import itertools
import json
import math
import re
import zipfile

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "src" / "base.lua"
TARGET_LINES = 50_000

EXTRA_DEFAULTS = {
    "freezeSelf": False,
    "bunnyHop": False,
    "airWalk": False,
    "voidReturn": False,
    "voidY": -100,
    "noAutoRotate": False,
    "alwaysSit": False,
    "clearAtmosphere": False,
    "exposure": False,
    "exposureValue": 0,
    "noBloom": False,
    "noShadows": False,
    "grade": False,
    "colorGrade": "Neutral",
    "freecam": False,
    "freecamSpeed": 40,
    "cameraSensitivity": 1,
    "orbit": False,
    "orbitRadius": 18,
    "orbitHeight": 6,
    "orbitSpeed": 20,
    "pathPlayback": False,
    "loopCamera": False,
    "rayDistance": 300,
    "bookmarkMarkers": False,
    "directionArrow": False,
    "dashSpeed": 75,
    "floatingHUD": False,
    "compass": True,
    "speedometer": True,
    "healthBar": True,
    "sessionStats": True,
    "rainbow": False,
    "hudOpacity": 0.85,
    "timerSeconds": 60,
}

EXTRA_BOUNDS = {
    "voidY": (-1000, -10, 10),
    "exposureValue": (-3, 3, 0.1),
    "freecamSpeed": (5, 150, 5),
    "cameraSensitivity": (0.2, 3, 0.1),
    "orbitRadius": (5, 100, 1),
    "orbitHeight": (-10, 50, 1),
    "orbitSpeed": (-90, 90, 5),
    "rayDistance": (25, 1000, 25),
    "dashSpeed": (10, 150, 5),
    "hudOpacity": (0.1, 1, 0.05),
    "timerSeconds": (5, 3600, 5),
}

# The expansion owns its schema; the builder merges it before creating UI.
for name, target in [("expanded-defaults.json", EXTRA_DEFAULTS), ("expanded-bounds.json", EXTRA_BOUNDS)]:
    path = ROOT / "src" / name
    if path.exists():
        entries = json.loads(path.read_text())
        overlap = set(entries) & set(target)
        if overlap:
            raise ValueError(f"Duplicate expansion schema keys: {sorted(overlap)}")
        target.update(entries)


def lua(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (float, int)) and math.isfinite(value):
        return str(value)
    raise TypeError(f"Unsupported Lua scalar: {value!r}")


def read_defaults(source):
    text = source.split("local defaults = {", 1)[1].split("\n}", 1)[0]
    result = {}
    for key, value in re.findall(r'(\w+)\s*=\s*("[^"]*"|true|false|-?[\d.]+)', text):
        result[key] = json.loads(value)
    if len(result) != 25:
        raise ValueError(f"Unexpected base schema: {len(result)} fields")
    result.update(EXTRA_DEFAULTS)
    return result


def prepare_engine(source):
    extra_schema = "\n".join(f"defaults.{key} = {lua(value)}" for key, value in EXTRA_DEFAULTS.items())
    extra_schema += "\n" + "\n".join(
        f"bounds.{key} = {{ {', '.join(map(lua, limits))} }}"
        for key, limits in EXTRA_BOUNDS.items()
    )
    source = source.replace("local values = table.clone(defaults)", extra_schema + "\nlocal values = table.clone(defaults)", 1)
    source = source.replace('local sidebar = new("Frame", {', 'local sidebar = new("ScrollingFrame", {', 1)
    source = source.replace(
        'Size = UDim2.new(0, 112, 1, -132),\n    BackgroundTransparency = 1,',
        'Size = UDim2.new(0, 112, 1, -132),\n    CanvasSize = UDim2.new(), ScrollBarThickness = 2, BorderSizePixel = 0,\n    AutomaticCanvasSize = Enum.AutomaticSize.Y, BackgroundTransparency = 1,',
        1,
    )
    source = source.replace(
        'tabLayout.FillDirection = compact and Enum.FillDirection.Horizontal or Enum.FillDirection.Vertical',
        'sidebar.AutomaticCanvasSize = compact and Enum.AutomaticSize.X or Enum.AutomaticSize.Y\n'
        '    sidebar.ScrollingDirection = compact and Enum.ScrollingDirection.X or Enum.ScrollingDirection.Y\n'
        '    tabLayout.FillDirection = compact and Enum.FillDirection.Horizontal or Enum.FillDirection.Vertical',
        1,
    )
    source = source.replace('compact and UDim2.new(1 / 6, -7, 0, 40)', 'compact and UDim2.fromOffset(88, 40)', 1)
    source = source.replace('item.button.TextSize = compact and 9 or 12', 'item.button.TextSize = 12', 1)
    upgrade = (ROOT / "src" / "upgrade.lua").read_text()
    expanded = (ROOT / "src" / "expanded.lua").read_text()
    context = '''
local installExpanded = (function()
EXPANDED_SOURCE
end)()
local expandedCleanup = installExpanded({
    new=new, text=text, round=round, colored=colored, button=button,
    page=page, note=note, action=action, toggle=toggle, slider=slider,
    connect=connect, guarded=guarded, define=define, setFeature=setFeature,
    values=values, defaults=defaults, features=features, bounds=bounds,
    put=put, release=release, refreshFeature=refreshFeature,
    notify=notify, copyText=copyText, gui=gui, effectFolder=effectFolder,
    player=player, Players=Players, Run=Run, Input=Input, Lighting=Lighting,
    workspace=workspace, sync=sync, watch=watch,
    getRoot=function() return root end,
    getHumanoid=function() return humanoid end,
    getCharacter=function() return character end,
    getSelectedPlayer=function() return selectedPlayer end,
    isAlive=function() return alive end,
})
'''.replace('EXPANDED_SOURCE', expanded)
    source = source.replace("local api = {}", upgrade + "\n" + context + "\nlocal api = {}", 1)
    source = source.replace(
        "    pcall(stopFlight)\n    pcall(features.spectate.disable)",
        "    pcall(expandedCleanup)\n    pcall(upgradeCleanup)\n    pcall(stopFlight)\n    pcall(features.spectate.disable)",
        1,
    )
    source = source.replace("NEBULA ULTRA", "NEBULA 50000")
    source = source.replace("NEBULA 15000", "NEBULA 50000")
    return source


def profile(index, defaults):
    combinations = list(itertools.product(range(8), range(6), range(4), range(3)))
    movement, mood, theme, jump = combinations[(index * 37) % len(combinations)]
    speeds = [16, 24, 32, 40, 48, 56, 64, 72]
    moods = ["Clear Day", "Warm Sunset", "Cool Night", "Monochrome", "Soft Film", "Bright Explorer"]
    names = ["Purple", "Cyan", "Emerald", "Rose"]
    grades = ["Neutral", "Warm", "Cool", "Mono", "Soft", "Filmic"]
    config = defaults.copy()
    config.update({
        "speed": True,
        "walkSpeed": speeds[movement],
        "jump": jump > 0,
        "jumpPower": 50 + jump * 20,
        "fullbright": mood in (0, 5),
        "clearFog": mood in (0, 5),
        "customTime": True,
        "clockTime": [14, 18, 0, 12, 16, 10][mood],
        "grade": mood != 0,
        "colorGrade": grades[mood],
        "fov": True,
        "fieldOfView": [70, 75, 80, 85, 90, 95, 100, 105][movement],
        "theme": names[theme],
        "floatingHUD": True,
        "bookmarkMarkers": mood == 5,
        "compass": True,
        "nightVision": False,
        "noBloom": mood in (0, 3),
        "reticle": mood not in (3, 4),
        "reticleColor": ["White", "Cyan", "Lime", "Rose"][theme],
        "reticleDynamic": movement >= 4,
        "reticleRing": jump == 2,
        "nearbyList": mood == 5,
        "motionMetrics": mood in (0, 5),
        "sceneBloom": mood in (1, 4),
        "sceneDepth": mood == 4,
        "letterbox": mood in (3, 4),
    })
    return {
        "id": f"nebula-{index + 1:04}",
        "name": f"{speeds[movement]} speed / J{jump} / {moods[mood]} / {names[theme]}",
        "category": moods[mood],
        "description": (
            f"Walk {speeds[movement]}, jump {'default' if jump == 0 else config['jumpPower']}, "
            f"FOV {config['fieldOfView']}, time {config['clockTime']}:00. "
            f"{moods[mood]}; tema {names[theme]}; HUD aktif. Flight dan teleport tidak diaktifkan otomatis."
        ),
        "values": config,
    }


def render_record(record, wrap_description=False):
    lines = ["    {"]
    for key in ("id", "name", "category", "description"):
        if key == "description" and wrap_description:
            lines.extend([f"        {key} =", f"            {lua(record[key])},"])
        else:
            lines.append(f"        {key} = {lua(record[key])},")
    lines.append("        values = {")
    lines.extend(f"            {key} = {lua(value)}," for key, value in record["values"].items())
    lines.extend(["        },", "    },"])
    return lines


def main():
    source = BASE.read_text()
    defaults = read_defaults(source)
    engine = prepare_engine(source)
    header = "-- Generated by nebula-50000/build.py. Presets are complete selectable profiles.\nlocal NEBULA_PRESETS = {\n"
    suffix = "}\n"
    engine_lines = len(engine.splitlines())
    overhead = len(header.splitlines()) + len(suffix.splitlines())
    per_record = len(render_record(profile(0, defaults)))
    number = (TARGET_LINES - engine_lines - overhead) // per_record
    if number < 1:
        raise ValueError("Engine exceeds source-line budget")
    if number > 8 * 6 * 4 * 3:
        raise ValueError("Line budget exceeds the meaningful unique profile space")
    records = [profile(index, defaults) for index in range(number)]
    fingerprints = {json.dumps(record["values"], sort_keys=True) for record in records}
    if len(fingerprints) != len(records):
        raise ValueError("Duplicate configuration snapshots")
    remainder = TARGET_LINES - engine_lines - overhead - number * per_record
    if remainder > number:
        raise ValueError("Not enough descriptions to wrap")
    catalog = header + "\n".join(
        line
        for index, record in enumerate(records)
        for line in render_record(record, index < remainder)
    ) + "\n" + suffix
    combined = catalog + engine
    if len(combined.splitlines()) != TARGET_LINES:
        raise AssertionError("Incorrect source-line count")
    output = ROOT / "dist"
    output.mkdir(exist_ok=True)
    for name in ("NEBULA_50000.lua", "NEBULA_50000.txt"):
        (output / name).write_text(combined)
    (output / "presets.json").write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n")
    (output / "defaults.json").write_text(json.dumps(defaults, indent=2) + "\n")
    digest = hashlib.sha256(combined.encode()).hexdigest()
    manifest = {
        "source_file": "NEBULA_50000.lua",
        "source_lines": TARGET_LINES,
        "engine_lines": engine_lines,
        "catalog_lines": len(catalog.splitlines()),
        "unique_presets": number,
        "configuration_fields": len(defaults),
        "sha256": digest,
        "roblox_runtime_tested": False,
        "executor_compatibility_tested": False,
        "anticheat_bypass_implemented": False,
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (output / "SHA256SUMS.txt").write_text(
        f"{digest}  NEBULA_50000.lua\n{digest}  NEBULA_50000.txt\n"
    )
    include = [
        "README.md", "build.py", "package.json", "package-lock.json",
        "src/base.lua", "src/upgrade.lua", "tests/check.mjs", "tests/mock-roblox.lua",
        "src/expanded.lua", "src/expanded-defaults.json", "src/expanded-bounds.json",
        "dist/NEBULA_50000.lua", "dist/NEBULA_50000.txt", "dist/presets.json",
        "dist/defaults.json", "dist/manifest.json", "dist/SHA256SUMS.txt",
    ]
    with zipfile.ZipFile(output / "NEBULA_50000_SOURCE.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for name in include:
            archive.write(ROOT / name, "nebula-50000/" + name)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
